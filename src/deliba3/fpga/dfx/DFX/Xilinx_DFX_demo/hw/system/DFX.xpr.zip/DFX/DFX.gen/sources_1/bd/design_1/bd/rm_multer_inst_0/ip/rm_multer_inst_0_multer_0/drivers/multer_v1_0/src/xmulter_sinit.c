// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmulter.h"

extern XMulter_Config XMulter_ConfigTable[];

XMulter_Config *XMulter_LookupConfig(u16 DeviceId) {
	XMulter_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMULTER_NUM_INSTANCES; Index++) {
		if (XMulter_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMulter_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMulter_Initialize(XMulter *InstancePtr, u16 DeviceId) {
	XMulter_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMulter_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMulter_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

