// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsubber.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSubber_CfgInitialize(XSubber *InstancePtr, XSubber_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSubber_Start(XSubber *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSubber_IsDone(XSubber *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSubber_IsIdle(XSubber *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSubber_IsReady(XSubber *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSubber_EnableAutoRestart(XSubber *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSubber_DisableAutoRestart(XSubber *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_AP_CTRL, 0);
}

void XSubber_InterruptGlobalEnable(XSubber *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_GIE, 1);
}

void XSubber_InterruptGlobalDisable(XSubber *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_GIE, 0);
}

void XSubber_InterruptEnable(XSubber *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_IER);
    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_IER, Register | Mask);
}

void XSubber_InterruptDisable(XSubber *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_IER);
    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSubber_InterruptClear(XSubber *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSubber_WriteReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_ISR, Mask);
}

u32 XSubber_InterruptGetEnabled(XSubber *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_IER);
}

u32 XSubber_InterruptGetStatus(XSubber *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSubber_ReadReg(InstancePtr->Control_BaseAddress, XSUBBER_CONTROL_ADDR_ISR);
}

