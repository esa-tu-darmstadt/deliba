// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xsubber.h"

extern XSubber_Config XSubber_ConfigTable[];

XSubber_Config *XSubber_LookupConfig(u16 DeviceId) {
	XSubber_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSUBBER_NUM_INSTANCES; Index++) {
		if (XSubber_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSubber_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSubber_Initialize(XSubber *InstancePtr, u16 DeviceId) {
	XSubber_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSubber_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSubber_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

