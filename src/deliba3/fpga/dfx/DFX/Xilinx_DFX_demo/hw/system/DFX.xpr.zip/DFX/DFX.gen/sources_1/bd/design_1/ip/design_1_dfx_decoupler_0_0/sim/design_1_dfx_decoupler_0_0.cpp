// (c) Copyright 1995-2022 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


#include "design_1_dfx_decoupler_0_0_sc.h"

#include "design_1_dfx_decoupler_0_0.h"

#include "design_1_dfx_decoupler_0_0_core.h"

#include <map>
#include <string>





#ifdef XILINX_SIMULATOR
design_1_dfx_decoupler_0_0::design_1_dfx_decoupler_0_0(const sc_core::sc_module_name& nm) : design_1_dfx_decoupler_0_0_sc(nm), s_stream_a_TVALID("s_stream_a_TVALID"), rp_stream_a_TVALID("rp_stream_a_TVALID"), s_stream_a_TREADY("s_stream_a_TREADY"), rp_stream_a_TREADY("rp_stream_a_TREADY"), s_stream_a_TDATA("s_stream_a_TDATA"), rp_stream_a_TDATA("rp_stream_a_TDATA"), s_stream_a_TLAST("s_stream_a_TLAST"), rp_stream_a_TLAST("rp_stream_a_TLAST"), s_stream_a_TKEEP("s_stream_a_TKEEP"), rp_stream_a_TKEEP("rp_stream_a_TKEEP"), s_stream_b_TVALID("s_stream_b_TVALID"), rp_stream_b_TVALID("rp_stream_b_TVALID"), s_stream_b_TREADY("s_stream_b_TREADY"), rp_stream_b_TREADY("rp_stream_b_TREADY"), s_stream_b_TDATA("s_stream_b_TDATA"), rp_stream_b_TDATA("rp_stream_b_TDATA"), s_stream_b_TLAST("s_stream_b_TLAST"), rp_stream_b_TLAST("rp_stream_b_TLAST"), s_stream_b_TKEEP("s_stream_b_TKEEP"), rp_stream_b_TKEEP("rp_stream_b_TKEEP"), s_stream_c_TVALID("s_stream_c_TVALID"), rp_stream_c_TVALID("rp_stream_c_TVALID"), s_stream_c_TREADY("s_stream_c_TREADY"), rp_stream_c_TREADY("rp_stream_c_TREADY"), s_stream_c_TDATA("s_stream_c_TDATA"), rp_stream_c_TDATA("rp_stream_c_TDATA"), s_stream_c_TUSER("s_stream_c_TUSER"), rp_stream_c_TUSER("rp_stream_c_TUSER"), s_stream_c_TLAST("s_stream_c_TLAST"), rp_stream_c_TLAST("rp_stream_c_TLAST"), s_stream_c_TID("s_stream_c_TID"), rp_stream_c_TID("rp_stream_c_TID"), s_stream_c_TDEST("s_stream_c_TDEST"), rp_stream_c_TDEST("rp_stream_c_TDEST"), s_stream_c_TSTRB("s_stream_c_TSTRB"), rp_stream_c_TSTRB("rp_stream_c_TSTRB"), s_stream_c_TKEEP("s_stream_c_TKEEP"), rp_stream_c_TKEEP("rp_stream_c_TKEEP"), s_axi_ctrl_ARVALID("s_axi_ctrl_ARVALID"), rp_axi_ctrl_ARVALID("rp_axi_ctrl_ARVALID"), s_axi_ctrl_ARREADY("s_axi_ctrl_ARREADY"), rp_axi_ctrl_ARREADY("rp_axi_ctrl_ARREADY"), s_axi_ctrl_AWVALID("s_axi_ctrl_AWVALID"), rp_axi_ctrl_AWVALID("rp_axi_ctrl_AWVALID"), s_axi_ctrl_AWREADY("s_axi_ctrl_AWREADY"), rp_axi_ctrl_AWREADY("rp_axi_ctrl_AWREADY"), s_axi_ctrl_BVALID("s_axi_ctrl_BVALID"), rp_axi_ctrl_BVALID("rp_axi_ctrl_BVALID"), s_axi_ctrl_BREADY("s_axi_ctrl_BREADY"), rp_axi_ctrl_BREADY("rp_axi_ctrl_BREADY"), s_axi_ctrl_RVALID("s_axi_ctrl_RVALID"), rp_axi_ctrl_RVALID("rp_axi_ctrl_RVALID"), s_axi_ctrl_RREADY("s_axi_ctrl_RREADY"), rp_axi_ctrl_RREADY("rp_axi_ctrl_RREADY"), s_axi_ctrl_WVALID("s_axi_ctrl_WVALID"), rp_axi_ctrl_WVALID("rp_axi_ctrl_WVALID"), s_axi_ctrl_WREADY("s_axi_ctrl_WREADY"), rp_axi_ctrl_WREADY("rp_axi_ctrl_WREADY"), s_axi_ctrl_AWADDR("s_axi_ctrl_AWADDR"), rp_axi_ctrl_AWADDR("rp_axi_ctrl_AWADDR"), s_axi_ctrl_AWPROT("s_axi_ctrl_AWPROT"), rp_axi_ctrl_AWPROT("rp_axi_ctrl_AWPROT"), s_axi_ctrl_AWREGION("s_axi_ctrl_AWREGION"), rp_axi_ctrl_AWREGION("rp_axi_ctrl_AWREGION"), s_axi_ctrl_AWQOS("s_axi_ctrl_AWQOS"), rp_axi_ctrl_AWQOS("rp_axi_ctrl_AWQOS"), s_axi_ctrl_WDATA("s_axi_ctrl_WDATA"), rp_axi_ctrl_WDATA("rp_axi_ctrl_WDATA"), s_axi_ctrl_WSTRB("s_axi_ctrl_WSTRB"), rp_axi_ctrl_WSTRB("rp_axi_ctrl_WSTRB"), s_axi_ctrl_BRESP("s_axi_ctrl_BRESP"), rp_axi_ctrl_BRESP("rp_axi_ctrl_BRESP"), s_axi_ctrl_ARADDR("s_axi_ctrl_ARADDR"), rp_axi_ctrl_ARADDR("rp_axi_ctrl_ARADDR"), s_axi_ctrl_ARPROT("s_axi_ctrl_ARPROT"), rp_axi_ctrl_ARPROT("rp_axi_ctrl_ARPROT"), s_axi_ctrl_ARREGION("s_axi_ctrl_ARREGION"), rp_axi_ctrl_ARREGION("rp_axi_ctrl_ARREGION"), s_axi_ctrl_ARQOS("s_axi_ctrl_ARQOS"), rp_axi_ctrl_ARQOS("rp_axi_ctrl_ARQOS"), s_axi_ctrl_RDATA("s_axi_ctrl_RDATA"), rp_axi_ctrl_RDATA("rp_axi_ctrl_RDATA"), s_axi_ctrl_RRESP("s_axi_ctrl_RRESP"), rp_axi_ctrl_RRESP("rp_axi_ctrl_RRESP"), s_interrupt_INTERRUPT("s_interrupt_INTERRUPT"), rp_interrupt_INTERRUPT("rp_interrupt_INTERRUPT"), s_reset_RST("s_reset_RST"), rp_reset_RST("rp_reset_RST"), decouple_status("decouple_status"), aclk("aclk"), s_axi_reg_awaddr("s_axi_reg_awaddr"), s_axi_reg_awvalid("s_axi_reg_awvalid"), s_axi_reg_awready("s_axi_reg_awready"), s_axi_reg_wdata("s_axi_reg_wdata"), s_axi_reg_wvalid("s_axi_reg_wvalid"), s_axi_reg_wready("s_axi_reg_wready"), s_axi_reg_bresp("s_axi_reg_bresp"), s_axi_reg_bvalid("s_axi_reg_bvalid"), s_axi_reg_bready("s_axi_reg_bready"), s_axi_reg_araddr("s_axi_reg_araddr"), s_axi_reg_arvalid("s_axi_reg_arvalid"), s_axi_reg_arready("s_axi_reg_arready"), s_axi_reg_rdata("s_axi_reg_rdata"), s_axi_reg_rresp("s_axi_reg_rresp"), s_axi_reg_rvalid("s_axi_reg_rvalid"), s_axi_reg_rready("s_axi_reg_rready"), s_axi_reg_aresetn("s_axi_reg_aresetn")
{

  // initialize pins
  mp_impl->s_interrupt_INTERRUPT(s_interrupt_INTERRUPT);
  mp_impl->rp_interrupt_INTERRUPT(rp_interrupt_INTERRUPT);
  mp_impl->s_reset_RST(s_reset_RST);
  mp_impl->rp_reset_RST(rp_reset_RST);
  mp_impl->decouple_status(decouple_status);
  mp_impl->aclk(aclk);
  mp_impl->s_axi_reg_aresetn(s_axi_reg_aresetn);

  // initialize transactors
  mp_s_stream_a_transactor = NULL;
  mp_rp_stream_a_transactor = NULL;
  mp_s_stream_b_transactor = NULL;
  mp_rp_stream_b_transactor = NULL;
  mp_s_stream_c_transactor = NULL;
  mp_rp_stream_c_transactor = NULL;
  mp_s_axi_ctrl_transactor = NULL;
  mp_rp_axi_ctrl_transactor = NULL;
  mp_s_axi_reg_transactor = NULL;

  // initialize socket stubs

}

void design_1_dfx_decoupler_0_0::before_end_of_elaboration()
{
  // configure 's_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_a' transactor parameters
    xsc::common_cpp::properties s_stream_a_transactor_param_props;
    s_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_a_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_a_transactor", s_stream_a_transactor_param_props);

    // s_stream_a' transactor ports

    mp_s_stream_a_transactor->TVALID(s_stream_a_TVALID);
    mp_s_stream_a_transactor->TREADY(s_stream_a_TREADY);
    mp_s_stream_a_transactor->TDATA(s_stream_a_TDATA);
    mp_s_stream_a_transactor->TLAST(s_stream_a_TLAST);
    mp_s_stream_a_transactor->TKEEP(s_stream_a_TKEEP);
    mp_s_stream_a_transactor->CLK(aclk);
    m_s_stream_a_transactor_rst_signal.write(1);
    mp_s_stream_a_transactor->RST(m_s_stream_a_transactor_rst_signal);

    // s_stream_a' transactor sockets

    mp_impl->S00_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_a' transactor parameters
    xsc::common_cpp::properties rp_stream_a_transactor_param_props;
    rp_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_a_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_a_transactor", rp_stream_a_transactor_param_props);

    // rp_stream_a' transactor ports

    mp_rp_stream_a_transactor->TVALID(rp_stream_a_TVALID);
    mp_rp_stream_a_transactor->TREADY(rp_stream_a_TREADY);
    mp_rp_stream_a_transactor->TDATA(rp_stream_a_TDATA);
    mp_rp_stream_a_transactor->TLAST(rp_stream_a_TLAST);
    mp_rp_stream_a_transactor->TKEEP(rp_stream_a_TKEEP);
    mp_rp_stream_a_transactor->CLK(aclk);
    m_rp_stream_a_transactor_rst_signal.write(1);
    mp_rp_stream_a_transactor->RST(m_rp_stream_a_transactor_rst_signal);

    // rp_stream_a' transactor sockets

    mp_impl->M00_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_b' transactor parameters
    xsc::common_cpp::properties s_stream_b_transactor_param_props;
    s_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_b_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_b_transactor", s_stream_b_transactor_param_props);

    // s_stream_b' transactor ports

    mp_s_stream_b_transactor->TVALID(s_stream_b_TVALID);
    mp_s_stream_b_transactor->TREADY(s_stream_b_TREADY);
    mp_s_stream_b_transactor->TDATA(s_stream_b_TDATA);
    mp_s_stream_b_transactor->TLAST(s_stream_b_TLAST);
    mp_s_stream_b_transactor->TKEEP(s_stream_b_TKEEP);
    mp_s_stream_b_transactor->CLK(aclk);
    m_s_stream_b_transactor_rst_signal.write(1);
    mp_s_stream_b_transactor->RST(m_s_stream_b_transactor_rst_signal);

    // s_stream_b' transactor sockets

    mp_impl->S01_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_b' transactor parameters
    xsc::common_cpp::properties rp_stream_b_transactor_param_props;
    rp_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_b_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_b_transactor", rp_stream_b_transactor_param_props);

    // rp_stream_b' transactor ports

    mp_rp_stream_b_transactor->TVALID(rp_stream_b_TVALID);
    mp_rp_stream_b_transactor->TREADY(rp_stream_b_TREADY);
    mp_rp_stream_b_transactor->TDATA(rp_stream_b_TDATA);
    mp_rp_stream_b_transactor->TLAST(rp_stream_b_TLAST);
    mp_rp_stream_b_transactor->TKEEP(rp_stream_b_TKEEP);
    mp_rp_stream_b_transactor->CLK(aclk);
    m_rp_stream_b_transactor_rst_signal.write(1);
    mp_rp_stream_b_transactor->RST(m_rp_stream_b_transactor_rst_signal);

    // rp_stream_b' transactor sockets

    mp_impl->M01_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_c' transactor parameters
    xsc::common_cpp::properties s_stream_c_transactor_param_props;
    s_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_c_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("s_stream_c_transactor", s_stream_c_transactor_param_props);

    // s_stream_c' transactor ports

    mp_s_stream_c_transactor->TVALID(s_stream_c_TVALID);
    mp_s_stream_c_transactor->TREADY(s_stream_c_TREADY);
    mp_s_stream_c_transactor->TDATA(s_stream_c_TDATA);
    mp_s_stream_c_transactor->TUSER(s_stream_c_TUSER);
    mp_s_stream_c_transactor->TLAST(s_stream_c_TLAST);
    mp_s_stream_c_transactor->TID(s_stream_c_TID);
    mp_s_stream_c_transactor->TDEST(s_stream_c_TDEST);
    mp_s_stream_c_transactor->TSTRB(s_stream_c_TSTRB);
    mp_s_stream_c_transactor->TKEEP(s_stream_c_TKEEP);
    mp_s_stream_c_transactor->CLK(aclk);
    m_s_stream_c_transactor_rst_signal.write(1);
    mp_s_stream_c_transactor->RST(m_s_stream_c_transactor_rst_signal);

    // s_stream_c' transactor sockets

    mp_impl->M02_AXIS_INITIATOR_SOCKET->bind(*(mp_s_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_c' transactor parameters
    xsc::common_cpp::properties rp_stream_c_transactor_param_props;
    rp_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_c_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("rp_stream_c_transactor", rp_stream_c_transactor_param_props);

    // rp_stream_c' transactor ports

    mp_rp_stream_c_transactor->TVALID(rp_stream_c_TVALID);
    mp_rp_stream_c_transactor->TREADY(rp_stream_c_TREADY);
    mp_rp_stream_c_transactor->TDATA(rp_stream_c_TDATA);
    mp_rp_stream_c_transactor->TUSER(rp_stream_c_TUSER);
    mp_rp_stream_c_transactor->TLAST(rp_stream_c_TLAST);
    mp_rp_stream_c_transactor->TID(rp_stream_c_TID);
    mp_rp_stream_c_transactor->TDEST(rp_stream_c_TDEST);
    mp_rp_stream_c_transactor->TSTRB(rp_stream_c_TSTRB);
    mp_rp_stream_c_transactor->TKEEP(rp_stream_c_TKEEP);
    mp_rp_stream_c_transactor->CLK(aclk);
    m_rp_stream_c_transactor_rst_signal.write(1);
    mp_rp_stream_c_transactor->RST(m_rp_stream_c_transactor_rst_signal);

    // rp_stream_c' transactor sockets

    mp_impl->S02_AXIS_TARGET_SOCKET->bind(*(mp_rp_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 's_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_ctrl' transactor parameters
    xsc::common_cpp::properties s_axi_ctrl_transactor_param_props;
    s_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    s_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    s_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_axi_ctrl_transactor = new xtlm::xaximm_pin2xtlm_t<32,16,1,1,1,1,1,1>("s_axi_ctrl_transactor", s_axi_ctrl_transactor_param_props);

    // s_axi_ctrl' transactor ports

    mp_s_axi_ctrl_transactor->ARVALID(s_axi_ctrl_ARVALID);
    mp_s_axi_ctrl_transactor->ARREADY(s_axi_ctrl_ARREADY);
    mp_s_axi_ctrl_transactor->AWVALID(s_axi_ctrl_AWVALID);
    mp_s_axi_ctrl_transactor->AWREADY(s_axi_ctrl_AWREADY);
    mp_s_axi_ctrl_transactor->BVALID(s_axi_ctrl_BVALID);
    mp_s_axi_ctrl_transactor->BREADY(s_axi_ctrl_BREADY);
    mp_s_axi_ctrl_transactor->RVALID(s_axi_ctrl_RVALID);
    mp_s_axi_ctrl_transactor->RREADY(s_axi_ctrl_RREADY);
    mp_s_axi_ctrl_transactor->WVALID(s_axi_ctrl_WVALID);
    mp_s_axi_ctrl_transactor->WREADY(s_axi_ctrl_WREADY);
    mp_s_axi_ctrl_transactor->AWADDR(s_axi_ctrl_AWADDR);
    mp_s_axi_ctrl_transactor->AWPROT(s_axi_ctrl_AWPROT);
    mp_s_axi_ctrl_transactor->AWREGION(s_axi_ctrl_AWREGION);
    mp_s_axi_ctrl_transactor->AWQOS(s_axi_ctrl_AWQOS);
    mp_s_axi_ctrl_transactor->WDATA(s_axi_ctrl_WDATA);
    mp_s_axi_ctrl_transactor->WSTRB(s_axi_ctrl_WSTRB);
    mp_s_axi_ctrl_transactor->BRESP(s_axi_ctrl_BRESP);
    mp_s_axi_ctrl_transactor->ARADDR(s_axi_ctrl_ARADDR);
    mp_s_axi_ctrl_transactor->ARPROT(s_axi_ctrl_ARPROT);
    mp_s_axi_ctrl_transactor->ARREGION(s_axi_ctrl_ARREGION);
    mp_s_axi_ctrl_transactor->ARQOS(s_axi_ctrl_ARQOS);
    mp_s_axi_ctrl_transactor->RDATA(s_axi_ctrl_RDATA);
    mp_s_axi_ctrl_transactor->RRESP(s_axi_ctrl_RRESP);
    mp_s_axi_ctrl_transactor->CLK(aclk);
    m_s_axi_ctrl_transactor_rst_signal.write(1);
    mp_s_axi_ctrl_transactor->RST(m_s_axi_ctrl_transactor_rst_signal);

    // s_axi_ctrl' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_axi_ctrl' transactor parameters
    xsc::common_cpp::properties rp_axi_ctrl_transactor_param_props;
    rp_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    rp_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    rp_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    rp_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_axi_ctrl_transactor = new xtlm::xaximm_xtlm2pin_t<32,16,1,1,1,1,1,1>("rp_axi_ctrl_transactor", rp_axi_ctrl_transactor_param_props);

    // rp_axi_ctrl' transactor ports

    mp_rp_axi_ctrl_transactor->ARVALID(rp_axi_ctrl_ARVALID);
    mp_rp_axi_ctrl_transactor->ARREADY(rp_axi_ctrl_ARREADY);
    mp_rp_axi_ctrl_transactor->AWVALID(rp_axi_ctrl_AWVALID);
    mp_rp_axi_ctrl_transactor->AWREADY(rp_axi_ctrl_AWREADY);
    mp_rp_axi_ctrl_transactor->BVALID(rp_axi_ctrl_BVALID);
    mp_rp_axi_ctrl_transactor->BREADY(rp_axi_ctrl_BREADY);
    mp_rp_axi_ctrl_transactor->RVALID(rp_axi_ctrl_RVALID);
    mp_rp_axi_ctrl_transactor->RREADY(rp_axi_ctrl_RREADY);
    mp_rp_axi_ctrl_transactor->WVALID(rp_axi_ctrl_WVALID);
    mp_rp_axi_ctrl_transactor->WREADY(rp_axi_ctrl_WREADY);
    mp_rp_axi_ctrl_transactor->AWADDR(rp_axi_ctrl_AWADDR);
    mp_rp_axi_ctrl_transactor->AWPROT(rp_axi_ctrl_AWPROT);
    mp_rp_axi_ctrl_transactor->AWREGION(rp_axi_ctrl_AWREGION);
    mp_rp_axi_ctrl_transactor->AWQOS(rp_axi_ctrl_AWQOS);
    mp_rp_axi_ctrl_transactor->WDATA(rp_axi_ctrl_WDATA);
    mp_rp_axi_ctrl_transactor->WSTRB(rp_axi_ctrl_WSTRB);
    mp_rp_axi_ctrl_transactor->BRESP(rp_axi_ctrl_BRESP);
    mp_rp_axi_ctrl_transactor->ARADDR(rp_axi_ctrl_ARADDR);
    mp_rp_axi_ctrl_transactor->ARPROT(rp_axi_ctrl_ARPROT);
    mp_rp_axi_ctrl_transactor->ARREGION(rp_axi_ctrl_ARREGION);
    mp_rp_axi_ctrl_transactor->ARQOS(rp_axi_ctrl_ARQOS);
    mp_rp_axi_ctrl_transactor->RDATA(rp_axi_ctrl_RDATA);
    mp_rp_axi_ctrl_transactor->RRESP(rp_axi_ctrl_RRESP);
    mp_rp_axi_ctrl_transactor->CLK(aclk);
    m_rp_axi_ctrl_transactor_rst_signal.write(1);
    mp_rp_axi_ctrl_transactor->RST(m_rp_axi_ctrl_transactor_rst_signal);

    // rp_axi_ctrl' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 's_axi_reg' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_reg_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_reg' transactor parameters
    xsc::common_cpp::properties s_axi_reg_transactor_param_props;
    s_axi_reg_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_reg_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_reg_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ADDR_WIDTH", "1");
    s_axi_reg_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_PROT", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_QOS", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_REGION", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_WSTRB", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_reg_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_reg_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_reg_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_reg_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_reg_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_reg_transactor_param_props.addString("CLK_DOMAIN", "design_1_zynq_ultra_ps_e_0_0_pl_clk0");

    mp_s_axi_reg_transactor = new xtlm::xaximm_pin2xtlm_t<32,1,1,1,1,1,1,1>("s_axi_reg_transactor", s_axi_reg_transactor_param_props);

    // s_axi_reg' transactor ports

    mp_s_axi_reg_transactor->AWADDR(s_axi_reg_awaddr);
    mp_s_axi_reg_transactor->AWVALID(s_axi_reg_awvalid);
    mp_s_axi_reg_transactor->AWREADY(s_axi_reg_awready);
    mp_s_axi_reg_transactor->WDATA(s_axi_reg_wdata);
    mp_s_axi_reg_transactor->WVALID(s_axi_reg_wvalid);
    mp_s_axi_reg_transactor->WREADY(s_axi_reg_wready);
    mp_s_axi_reg_transactor->BRESP(s_axi_reg_bresp);
    mp_s_axi_reg_transactor->BVALID(s_axi_reg_bvalid);
    mp_s_axi_reg_transactor->BREADY(s_axi_reg_bready);
    mp_s_axi_reg_transactor->ARADDR(s_axi_reg_araddr);
    mp_s_axi_reg_transactor->ARVALID(s_axi_reg_arvalid);
    mp_s_axi_reg_transactor->ARREADY(s_axi_reg_arready);
    mp_s_axi_reg_transactor->RDATA(s_axi_reg_rdata);
    mp_s_axi_reg_transactor->RRESP(s_axi_reg_rresp);
    mp_s_axi_reg_transactor->RVALID(s_axi_reg_rvalid);
    mp_s_axi_reg_transactor->RREADY(s_axi_reg_rready);
    mp_s_axi_reg_transactor->CLK(aclk);
    m_s_axi_reg_transactor_rst_signal.write(1);
    mp_s_axi_reg_transactor->RST(m_s_axi_reg_transactor_rst_signal);

    // s_axi_reg' transactor sockets

    mp_impl->axilite_wr_socket->bind(*(mp_s_axi_reg_transactor->wr_socket));
    mp_impl->axilite_rd_socket->bind(*(mp_s_axi_reg_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // XILINX_SIMULATOR




#ifdef XM_SYSTEMC
design_1_dfx_decoupler_0_0::design_1_dfx_decoupler_0_0(const sc_core::sc_module_name& nm) : design_1_dfx_decoupler_0_0_sc(nm), s_stream_a_TVALID("s_stream_a_TVALID"), rp_stream_a_TVALID("rp_stream_a_TVALID"), s_stream_a_TREADY("s_stream_a_TREADY"), rp_stream_a_TREADY("rp_stream_a_TREADY"), s_stream_a_TDATA("s_stream_a_TDATA"), rp_stream_a_TDATA("rp_stream_a_TDATA"), s_stream_a_TLAST("s_stream_a_TLAST"), rp_stream_a_TLAST("rp_stream_a_TLAST"), s_stream_a_TKEEP("s_stream_a_TKEEP"), rp_stream_a_TKEEP("rp_stream_a_TKEEP"), s_stream_b_TVALID("s_stream_b_TVALID"), rp_stream_b_TVALID("rp_stream_b_TVALID"), s_stream_b_TREADY("s_stream_b_TREADY"), rp_stream_b_TREADY("rp_stream_b_TREADY"), s_stream_b_TDATA("s_stream_b_TDATA"), rp_stream_b_TDATA("rp_stream_b_TDATA"), s_stream_b_TLAST("s_stream_b_TLAST"), rp_stream_b_TLAST("rp_stream_b_TLAST"), s_stream_b_TKEEP("s_stream_b_TKEEP"), rp_stream_b_TKEEP("rp_stream_b_TKEEP"), s_stream_c_TVALID("s_stream_c_TVALID"), rp_stream_c_TVALID("rp_stream_c_TVALID"), s_stream_c_TREADY("s_stream_c_TREADY"), rp_stream_c_TREADY("rp_stream_c_TREADY"), s_stream_c_TDATA("s_stream_c_TDATA"), rp_stream_c_TDATA("rp_stream_c_TDATA"), s_stream_c_TUSER("s_stream_c_TUSER"), rp_stream_c_TUSER("rp_stream_c_TUSER"), s_stream_c_TLAST("s_stream_c_TLAST"), rp_stream_c_TLAST("rp_stream_c_TLAST"), s_stream_c_TID("s_stream_c_TID"), rp_stream_c_TID("rp_stream_c_TID"), s_stream_c_TDEST("s_stream_c_TDEST"), rp_stream_c_TDEST("rp_stream_c_TDEST"), s_stream_c_TSTRB("s_stream_c_TSTRB"), rp_stream_c_TSTRB("rp_stream_c_TSTRB"), s_stream_c_TKEEP("s_stream_c_TKEEP"), rp_stream_c_TKEEP("rp_stream_c_TKEEP"), s_axi_ctrl_ARVALID("s_axi_ctrl_ARVALID"), rp_axi_ctrl_ARVALID("rp_axi_ctrl_ARVALID"), s_axi_ctrl_ARREADY("s_axi_ctrl_ARREADY"), rp_axi_ctrl_ARREADY("rp_axi_ctrl_ARREADY"), s_axi_ctrl_AWVALID("s_axi_ctrl_AWVALID"), rp_axi_ctrl_AWVALID("rp_axi_ctrl_AWVALID"), s_axi_ctrl_AWREADY("s_axi_ctrl_AWREADY"), rp_axi_ctrl_AWREADY("rp_axi_ctrl_AWREADY"), s_axi_ctrl_BVALID("s_axi_ctrl_BVALID"), rp_axi_ctrl_BVALID("rp_axi_ctrl_BVALID"), s_axi_ctrl_BREADY("s_axi_ctrl_BREADY"), rp_axi_ctrl_BREADY("rp_axi_ctrl_BREADY"), s_axi_ctrl_RVALID("s_axi_ctrl_RVALID"), rp_axi_ctrl_RVALID("rp_axi_ctrl_RVALID"), s_axi_ctrl_RREADY("s_axi_ctrl_RREADY"), rp_axi_ctrl_RREADY("rp_axi_ctrl_RREADY"), s_axi_ctrl_WVALID("s_axi_ctrl_WVALID"), rp_axi_ctrl_WVALID("rp_axi_ctrl_WVALID"), s_axi_ctrl_WREADY("s_axi_ctrl_WREADY"), rp_axi_ctrl_WREADY("rp_axi_ctrl_WREADY"), s_axi_ctrl_AWADDR("s_axi_ctrl_AWADDR"), rp_axi_ctrl_AWADDR("rp_axi_ctrl_AWADDR"), s_axi_ctrl_AWPROT("s_axi_ctrl_AWPROT"), rp_axi_ctrl_AWPROT("rp_axi_ctrl_AWPROT"), s_axi_ctrl_AWREGION("s_axi_ctrl_AWREGION"), rp_axi_ctrl_AWREGION("rp_axi_ctrl_AWREGION"), s_axi_ctrl_AWQOS("s_axi_ctrl_AWQOS"), rp_axi_ctrl_AWQOS("rp_axi_ctrl_AWQOS"), s_axi_ctrl_WDATA("s_axi_ctrl_WDATA"), rp_axi_ctrl_WDATA("rp_axi_ctrl_WDATA"), s_axi_ctrl_WSTRB("s_axi_ctrl_WSTRB"), rp_axi_ctrl_WSTRB("rp_axi_ctrl_WSTRB"), s_axi_ctrl_BRESP("s_axi_ctrl_BRESP"), rp_axi_ctrl_BRESP("rp_axi_ctrl_BRESP"), s_axi_ctrl_ARADDR("s_axi_ctrl_ARADDR"), rp_axi_ctrl_ARADDR("rp_axi_ctrl_ARADDR"), s_axi_ctrl_ARPROT("s_axi_ctrl_ARPROT"), rp_axi_ctrl_ARPROT("rp_axi_ctrl_ARPROT"), s_axi_ctrl_ARREGION("s_axi_ctrl_ARREGION"), rp_axi_ctrl_ARREGION("rp_axi_ctrl_ARREGION"), s_axi_ctrl_ARQOS("s_axi_ctrl_ARQOS"), rp_axi_ctrl_ARQOS("rp_axi_ctrl_ARQOS"), s_axi_ctrl_RDATA("s_axi_ctrl_RDATA"), rp_axi_ctrl_RDATA("rp_axi_ctrl_RDATA"), s_axi_ctrl_RRESP("s_axi_ctrl_RRESP"), rp_axi_ctrl_RRESP("rp_axi_ctrl_RRESP"), s_interrupt_INTERRUPT("s_interrupt_INTERRUPT"), rp_interrupt_INTERRUPT("rp_interrupt_INTERRUPT"), s_reset_RST("s_reset_RST"), rp_reset_RST("rp_reset_RST"), decouple_status("decouple_status"), aclk("aclk"), s_axi_reg_awaddr("s_axi_reg_awaddr"), s_axi_reg_awvalid("s_axi_reg_awvalid"), s_axi_reg_awready("s_axi_reg_awready"), s_axi_reg_wdata("s_axi_reg_wdata"), s_axi_reg_wvalid("s_axi_reg_wvalid"), s_axi_reg_wready("s_axi_reg_wready"), s_axi_reg_bresp("s_axi_reg_bresp"), s_axi_reg_bvalid("s_axi_reg_bvalid"), s_axi_reg_bready("s_axi_reg_bready"), s_axi_reg_araddr("s_axi_reg_araddr"), s_axi_reg_arvalid("s_axi_reg_arvalid"), s_axi_reg_arready("s_axi_reg_arready"), s_axi_reg_rdata("s_axi_reg_rdata"), s_axi_reg_rresp("s_axi_reg_rresp"), s_axi_reg_rvalid("s_axi_reg_rvalid"), s_axi_reg_rready("s_axi_reg_rready"), s_axi_reg_aresetn("s_axi_reg_aresetn")
{

  // initialize pins
  mp_impl->s_interrupt_INTERRUPT(s_interrupt_INTERRUPT);
  mp_impl->rp_interrupt_INTERRUPT(rp_interrupt_INTERRUPT);
  mp_impl->s_reset_RST(s_reset_RST);
  mp_impl->rp_reset_RST(rp_reset_RST);
  mp_impl->decouple_status(decouple_status);
  mp_impl->aclk(aclk);
  mp_impl->s_axi_reg_aresetn(s_axi_reg_aresetn);

  // initialize transactors
  mp_s_stream_a_transactor = NULL;
  mp_rp_stream_a_transactor = NULL;
  mp_s_stream_b_transactor = NULL;
  mp_rp_stream_b_transactor = NULL;
  mp_s_stream_c_transactor = NULL;
  mp_rp_stream_c_transactor = NULL;
  mp_s_axi_ctrl_transactor = NULL;
  mp_rp_axi_ctrl_transactor = NULL;
  mp_s_axi_reg_transactor = NULL;

  // initialize socket stubs

}

void design_1_dfx_decoupler_0_0::before_end_of_elaboration()
{
  // configure 's_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_a' transactor parameters
    xsc::common_cpp::properties s_stream_a_transactor_param_props;
    s_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_a_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_a_transactor", s_stream_a_transactor_param_props);

    // s_stream_a' transactor ports

    mp_s_stream_a_transactor->TVALID(s_stream_a_TVALID);
    mp_s_stream_a_transactor->TREADY(s_stream_a_TREADY);
    mp_s_stream_a_transactor->TDATA(s_stream_a_TDATA);
    mp_s_stream_a_transactor->TLAST(s_stream_a_TLAST);
    mp_s_stream_a_transactor->TKEEP(s_stream_a_TKEEP);
    mp_s_stream_a_transactor->CLK(aclk);
    m_s_stream_a_transactor_rst_signal.write(1);
    mp_s_stream_a_transactor->RST(m_s_stream_a_transactor_rst_signal);

    // s_stream_a' transactor sockets

    mp_impl->S00_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_a' transactor parameters
    xsc::common_cpp::properties rp_stream_a_transactor_param_props;
    rp_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_a_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_a_transactor", rp_stream_a_transactor_param_props);

    // rp_stream_a' transactor ports

    mp_rp_stream_a_transactor->TVALID(rp_stream_a_TVALID);
    mp_rp_stream_a_transactor->TREADY(rp_stream_a_TREADY);
    mp_rp_stream_a_transactor->TDATA(rp_stream_a_TDATA);
    mp_rp_stream_a_transactor->TLAST(rp_stream_a_TLAST);
    mp_rp_stream_a_transactor->TKEEP(rp_stream_a_TKEEP);
    mp_rp_stream_a_transactor->CLK(aclk);
    m_rp_stream_a_transactor_rst_signal.write(1);
    mp_rp_stream_a_transactor->RST(m_rp_stream_a_transactor_rst_signal);

    // rp_stream_a' transactor sockets

    mp_impl->M00_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_b' transactor parameters
    xsc::common_cpp::properties s_stream_b_transactor_param_props;
    s_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_b_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_b_transactor", s_stream_b_transactor_param_props);

    // s_stream_b' transactor ports

    mp_s_stream_b_transactor->TVALID(s_stream_b_TVALID);
    mp_s_stream_b_transactor->TREADY(s_stream_b_TREADY);
    mp_s_stream_b_transactor->TDATA(s_stream_b_TDATA);
    mp_s_stream_b_transactor->TLAST(s_stream_b_TLAST);
    mp_s_stream_b_transactor->TKEEP(s_stream_b_TKEEP);
    mp_s_stream_b_transactor->CLK(aclk);
    m_s_stream_b_transactor_rst_signal.write(1);
    mp_s_stream_b_transactor->RST(m_s_stream_b_transactor_rst_signal);

    // s_stream_b' transactor sockets

    mp_impl->S01_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_b' transactor parameters
    xsc::common_cpp::properties rp_stream_b_transactor_param_props;
    rp_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_b_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_b_transactor", rp_stream_b_transactor_param_props);

    // rp_stream_b' transactor ports

    mp_rp_stream_b_transactor->TVALID(rp_stream_b_TVALID);
    mp_rp_stream_b_transactor->TREADY(rp_stream_b_TREADY);
    mp_rp_stream_b_transactor->TDATA(rp_stream_b_TDATA);
    mp_rp_stream_b_transactor->TLAST(rp_stream_b_TLAST);
    mp_rp_stream_b_transactor->TKEEP(rp_stream_b_TKEEP);
    mp_rp_stream_b_transactor->CLK(aclk);
    m_rp_stream_b_transactor_rst_signal.write(1);
    mp_rp_stream_b_transactor->RST(m_rp_stream_b_transactor_rst_signal);

    // rp_stream_b' transactor sockets

    mp_impl->M01_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_c' transactor parameters
    xsc::common_cpp::properties s_stream_c_transactor_param_props;
    s_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_c_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("s_stream_c_transactor", s_stream_c_transactor_param_props);

    // s_stream_c' transactor ports

    mp_s_stream_c_transactor->TVALID(s_stream_c_TVALID);
    mp_s_stream_c_transactor->TREADY(s_stream_c_TREADY);
    mp_s_stream_c_transactor->TDATA(s_stream_c_TDATA);
    mp_s_stream_c_transactor->TUSER(s_stream_c_TUSER);
    mp_s_stream_c_transactor->TLAST(s_stream_c_TLAST);
    mp_s_stream_c_transactor->TID(s_stream_c_TID);
    mp_s_stream_c_transactor->TDEST(s_stream_c_TDEST);
    mp_s_stream_c_transactor->TSTRB(s_stream_c_TSTRB);
    mp_s_stream_c_transactor->TKEEP(s_stream_c_TKEEP);
    mp_s_stream_c_transactor->CLK(aclk);
    m_s_stream_c_transactor_rst_signal.write(1);
    mp_s_stream_c_transactor->RST(m_s_stream_c_transactor_rst_signal);

    // s_stream_c' transactor sockets

    mp_impl->M02_AXIS_INITIATOR_SOCKET->bind(*(mp_s_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_c' transactor parameters
    xsc::common_cpp::properties rp_stream_c_transactor_param_props;
    rp_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_c_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("rp_stream_c_transactor", rp_stream_c_transactor_param_props);

    // rp_stream_c' transactor ports

    mp_rp_stream_c_transactor->TVALID(rp_stream_c_TVALID);
    mp_rp_stream_c_transactor->TREADY(rp_stream_c_TREADY);
    mp_rp_stream_c_transactor->TDATA(rp_stream_c_TDATA);
    mp_rp_stream_c_transactor->TUSER(rp_stream_c_TUSER);
    mp_rp_stream_c_transactor->TLAST(rp_stream_c_TLAST);
    mp_rp_stream_c_transactor->TID(rp_stream_c_TID);
    mp_rp_stream_c_transactor->TDEST(rp_stream_c_TDEST);
    mp_rp_stream_c_transactor->TSTRB(rp_stream_c_TSTRB);
    mp_rp_stream_c_transactor->TKEEP(rp_stream_c_TKEEP);
    mp_rp_stream_c_transactor->CLK(aclk);
    m_rp_stream_c_transactor_rst_signal.write(1);
    mp_rp_stream_c_transactor->RST(m_rp_stream_c_transactor_rst_signal);

    // rp_stream_c' transactor sockets

    mp_impl->S02_AXIS_TARGET_SOCKET->bind(*(mp_rp_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 's_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_ctrl' transactor parameters
    xsc::common_cpp::properties s_axi_ctrl_transactor_param_props;
    s_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    s_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    s_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_axi_ctrl_transactor = new xtlm::xaximm_pin2xtlm_t<32,16,1,1,1,1,1,1>("s_axi_ctrl_transactor", s_axi_ctrl_transactor_param_props);

    // s_axi_ctrl' transactor ports

    mp_s_axi_ctrl_transactor->ARVALID(s_axi_ctrl_ARVALID);
    mp_s_axi_ctrl_transactor->ARREADY(s_axi_ctrl_ARREADY);
    mp_s_axi_ctrl_transactor->AWVALID(s_axi_ctrl_AWVALID);
    mp_s_axi_ctrl_transactor->AWREADY(s_axi_ctrl_AWREADY);
    mp_s_axi_ctrl_transactor->BVALID(s_axi_ctrl_BVALID);
    mp_s_axi_ctrl_transactor->BREADY(s_axi_ctrl_BREADY);
    mp_s_axi_ctrl_transactor->RVALID(s_axi_ctrl_RVALID);
    mp_s_axi_ctrl_transactor->RREADY(s_axi_ctrl_RREADY);
    mp_s_axi_ctrl_transactor->WVALID(s_axi_ctrl_WVALID);
    mp_s_axi_ctrl_transactor->WREADY(s_axi_ctrl_WREADY);
    mp_s_axi_ctrl_transactor->AWADDR(s_axi_ctrl_AWADDR);
    mp_s_axi_ctrl_transactor->AWPROT(s_axi_ctrl_AWPROT);
    mp_s_axi_ctrl_transactor->AWREGION(s_axi_ctrl_AWREGION);
    mp_s_axi_ctrl_transactor->AWQOS(s_axi_ctrl_AWQOS);
    mp_s_axi_ctrl_transactor->WDATA(s_axi_ctrl_WDATA);
    mp_s_axi_ctrl_transactor->WSTRB(s_axi_ctrl_WSTRB);
    mp_s_axi_ctrl_transactor->BRESP(s_axi_ctrl_BRESP);
    mp_s_axi_ctrl_transactor->ARADDR(s_axi_ctrl_ARADDR);
    mp_s_axi_ctrl_transactor->ARPROT(s_axi_ctrl_ARPROT);
    mp_s_axi_ctrl_transactor->ARREGION(s_axi_ctrl_ARREGION);
    mp_s_axi_ctrl_transactor->ARQOS(s_axi_ctrl_ARQOS);
    mp_s_axi_ctrl_transactor->RDATA(s_axi_ctrl_RDATA);
    mp_s_axi_ctrl_transactor->RRESP(s_axi_ctrl_RRESP);
    mp_s_axi_ctrl_transactor->CLK(aclk);
    m_s_axi_ctrl_transactor_rst_signal.write(1);
    mp_s_axi_ctrl_transactor->RST(m_s_axi_ctrl_transactor_rst_signal);

    // s_axi_ctrl' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_axi_ctrl' transactor parameters
    xsc::common_cpp::properties rp_axi_ctrl_transactor_param_props;
    rp_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    rp_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    rp_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    rp_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_axi_ctrl_transactor = new xtlm::xaximm_xtlm2pin_t<32,16,1,1,1,1,1,1>("rp_axi_ctrl_transactor", rp_axi_ctrl_transactor_param_props);

    // rp_axi_ctrl' transactor ports

    mp_rp_axi_ctrl_transactor->ARVALID(rp_axi_ctrl_ARVALID);
    mp_rp_axi_ctrl_transactor->ARREADY(rp_axi_ctrl_ARREADY);
    mp_rp_axi_ctrl_transactor->AWVALID(rp_axi_ctrl_AWVALID);
    mp_rp_axi_ctrl_transactor->AWREADY(rp_axi_ctrl_AWREADY);
    mp_rp_axi_ctrl_transactor->BVALID(rp_axi_ctrl_BVALID);
    mp_rp_axi_ctrl_transactor->BREADY(rp_axi_ctrl_BREADY);
    mp_rp_axi_ctrl_transactor->RVALID(rp_axi_ctrl_RVALID);
    mp_rp_axi_ctrl_transactor->RREADY(rp_axi_ctrl_RREADY);
    mp_rp_axi_ctrl_transactor->WVALID(rp_axi_ctrl_WVALID);
    mp_rp_axi_ctrl_transactor->WREADY(rp_axi_ctrl_WREADY);
    mp_rp_axi_ctrl_transactor->AWADDR(rp_axi_ctrl_AWADDR);
    mp_rp_axi_ctrl_transactor->AWPROT(rp_axi_ctrl_AWPROT);
    mp_rp_axi_ctrl_transactor->AWREGION(rp_axi_ctrl_AWREGION);
    mp_rp_axi_ctrl_transactor->AWQOS(rp_axi_ctrl_AWQOS);
    mp_rp_axi_ctrl_transactor->WDATA(rp_axi_ctrl_WDATA);
    mp_rp_axi_ctrl_transactor->WSTRB(rp_axi_ctrl_WSTRB);
    mp_rp_axi_ctrl_transactor->BRESP(rp_axi_ctrl_BRESP);
    mp_rp_axi_ctrl_transactor->ARADDR(rp_axi_ctrl_ARADDR);
    mp_rp_axi_ctrl_transactor->ARPROT(rp_axi_ctrl_ARPROT);
    mp_rp_axi_ctrl_transactor->ARREGION(rp_axi_ctrl_ARREGION);
    mp_rp_axi_ctrl_transactor->ARQOS(rp_axi_ctrl_ARQOS);
    mp_rp_axi_ctrl_transactor->RDATA(rp_axi_ctrl_RDATA);
    mp_rp_axi_ctrl_transactor->RRESP(rp_axi_ctrl_RRESP);
    mp_rp_axi_ctrl_transactor->CLK(aclk);
    m_rp_axi_ctrl_transactor_rst_signal.write(1);
    mp_rp_axi_ctrl_transactor->RST(m_rp_axi_ctrl_transactor_rst_signal);

    // rp_axi_ctrl' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 's_axi_reg' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_reg_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_reg' transactor parameters
    xsc::common_cpp::properties s_axi_reg_transactor_param_props;
    s_axi_reg_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_reg_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_reg_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ADDR_WIDTH", "1");
    s_axi_reg_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_PROT", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_QOS", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_REGION", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_WSTRB", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_reg_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_reg_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_reg_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_reg_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_reg_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_reg_transactor_param_props.addString("CLK_DOMAIN", "design_1_zynq_ultra_ps_e_0_0_pl_clk0");

    mp_s_axi_reg_transactor = new xtlm::xaximm_pin2xtlm_t<32,1,1,1,1,1,1,1>("s_axi_reg_transactor", s_axi_reg_transactor_param_props);

    // s_axi_reg' transactor ports

    mp_s_axi_reg_transactor->AWADDR(s_axi_reg_awaddr);
    mp_s_axi_reg_transactor->AWVALID(s_axi_reg_awvalid);
    mp_s_axi_reg_transactor->AWREADY(s_axi_reg_awready);
    mp_s_axi_reg_transactor->WDATA(s_axi_reg_wdata);
    mp_s_axi_reg_transactor->WVALID(s_axi_reg_wvalid);
    mp_s_axi_reg_transactor->WREADY(s_axi_reg_wready);
    mp_s_axi_reg_transactor->BRESP(s_axi_reg_bresp);
    mp_s_axi_reg_transactor->BVALID(s_axi_reg_bvalid);
    mp_s_axi_reg_transactor->BREADY(s_axi_reg_bready);
    mp_s_axi_reg_transactor->ARADDR(s_axi_reg_araddr);
    mp_s_axi_reg_transactor->ARVALID(s_axi_reg_arvalid);
    mp_s_axi_reg_transactor->ARREADY(s_axi_reg_arready);
    mp_s_axi_reg_transactor->RDATA(s_axi_reg_rdata);
    mp_s_axi_reg_transactor->RRESP(s_axi_reg_rresp);
    mp_s_axi_reg_transactor->RVALID(s_axi_reg_rvalid);
    mp_s_axi_reg_transactor->RREADY(s_axi_reg_rready);
    mp_s_axi_reg_transactor->CLK(aclk);
    m_s_axi_reg_transactor_rst_signal.write(1);
    mp_s_axi_reg_transactor->RST(m_s_axi_reg_transactor_rst_signal);

    // s_axi_reg' transactor sockets

    mp_impl->axilite_wr_socket->bind(*(mp_s_axi_reg_transactor->wr_socket));
    mp_impl->axilite_rd_socket->bind(*(mp_s_axi_reg_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // XM_SYSTEMC




#ifdef RIVIERA
design_1_dfx_decoupler_0_0::design_1_dfx_decoupler_0_0(const sc_core::sc_module_name& nm) : design_1_dfx_decoupler_0_0_sc(nm), s_stream_a_TVALID("s_stream_a_TVALID"), rp_stream_a_TVALID("rp_stream_a_TVALID"), s_stream_a_TREADY("s_stream_a_TREADY"), rp_stream_a_TREADY("rp_stream_a_TREADY"), s_stream_a_TDATA("s_stream_a_TDATA"), rp_stream_a_TDATA("rp_stream_a_TDATA"), s_stream_a_TLAST("s_stream_a_TLAST"), rp_stream_a_TLAST("rp_stream_a_TLAST"), s_stream_a_TKEEP("s_stream_a_TKEEP"), rp_stream_a_TKEEP("rp_stream_a_TKEEP"), s_stream_b_TVALID("s_stream_b_TVALID"), rp_stream_b_TVALID("rp_stream_b_TVALID"), s_stream_b_TREADY("s_stream_b_TREADY"), rp_stream_b_TREADY("rp_stream_b_TREADY"), s_stream_b_TDATA("s_stream_b_TDATA"), rp_stream_b_TDATA("rp_stream_b_TDATA"), s_stream_b_TLAST("s_stream_b_TLAST"), rp_stream_b_TLAST("rp_stream_b_TLAST"), s_stream_b_TKEEP("s_stream_b_TKEEP"), rp_stream_b_TKEEP("rp_stream_b_TKEEP"), s_stream_c_TVALID("s_stream_c_TVALID"), rp_stream_c_TVALID("rp_stream_c_TVALID"), s_stream_c_TREADY("s_stream_c_TREADY"), rp_stream_c_TREADY("rp_stream_c_TREADY"), s_stream_c_TDATA("s_stream_c_TDATA"), rp_stream_c_TDATA("rp_stream_c_TDATA"), s_stream_c_TUSER("s_stream_c_TUSER"), rp_stream_c_TUSER("rp_stream_c_TUSER"), s_stream_c_TLAST("s_stream_c_TLAST"), rp_stream_c_TLAST("rp_stream_c_TLAST"), s_stream_c_TID("s_stream_c_TID"), rp_stream_c_TID("rp_stream_c_TID"), s_stream_c_TDEST("s_stream_c_TDEST"), rp_stream_c_TDEST("rp_stream_c_TDEST"), s_stream_c_TSTRB("s_stream_c_TSTRB"), rp_stream_c_TSTRB("rp_stream_c_TSTRB"), s_stream_c_TKEEP("s_stream_c_TKEEP"), rp_stream_c_TKEEP("rp_stream_c_TKEEP"), s_axi_ctrl_ARVALID("s_axi_ctrl_ARVALID"), rp_axi_ctrl_ARVALID("rp_axi_ctrl_ARVALID"), s_axi_ctrl_ARREADY("s_axi_ctrl_ARREADY"), rp_axi_ctrl_ARREADY("rp_axi_ctrl_ARREADY"), s_axi_ctrl_AWVALID("s_axi_ctrl_AWVALID"), rp_axi_ctrl_AWVALID("rp_axi_ctrl_AWVALID"), s_axi_ctrl_AWREADY("s_axi_ctrl_AWREADY"), rp_axi_ctrl_AWREADY("rp_axi_ctrl_AWREADY"), s_axi_ctrl_BVALID("s_axi_ctrl_BVALID"), rp_axi_ctrl_BVALID("rp_axi_ctrl_BVALID"), s_axi_ctrl_BREADY("s_axi_ctrl_BREADY"), rp_axi_ctrl_BREADY("rp_axi_ctrl_BREADY"), s_axi_ctrl_RVALID("s_axi_ctrl_RVALID"), rp_axi_ctrl_RVALID("rp_axi_ctrl_RVALID"), s_axi_ctrl_RREADY("s_axi_ctrl_RREADY"), rp_axi_ctrl_RREADY("rp_axi_ctrl_RREADY"), s_axi_ctrl_WVALID("s_axi_ctrl_WVALID"), rp_axi_ctrl_WVALID("rp_axi_ctrl_WVALID"), s_axi_ctrl_WREADY("s_axi_ctrl_WREADY"), rp_axi_ctrl_WREADY("rp_axi_ctrl_WREADY"), s_axi_ctrl_AWADDR("s_axi_ctrl_AWADDR"), rp_axi_ctrl_AWADDR("rp_axi_ctrl_AWADDR"), s_axi_ctrl_AWPROT("s_axi_ctrl_AWPROT"), rp_axi_ctrl_AWPROT("rp_axi_ctrl_AWPROT"), s_axi_ctrl_AWREGION("s_axi_ctrl_AWREGION"), rp_axi_ctrl_AWREGION("rp_axi_ctrl_AWREGION"), s_axi_ctrl_AWQOS("s_axi_ctrl_AWQOS"), rp_axi_ctrl_AWQOS("rp_axi_ctrl_AWQOS"), s_axi_ctrl_WDATA("s_axi_ctrl_WDATA"), rp_axi_ctrl_WDATA("rp_axi_ctrl_WDATA"), s_axi_ctrl_WSTRB("s_axi_ctrl_WSTRB"), rp_axi_ctrl_WSTRB("rp_axi_ctrl_WSTRB"), s_axi_ctrl_BRESP("s_axi_ctrl_BRESP"), rp_axi_ctrl_BRESP("rp_axi_ctrl_BRESP"), s_axi_ctrl_ARADDR("s_axi_ctrl_ARADDR"), rp_axi_ctrl_ARADDR("rp_axi_ctrl_ARADDR"), s_axi_ctrl_ARPROT("s_axi_ctrl_ARPROT"), rp_axi_ctrl_ARPROT("rp_axi_ctrl_ARPROT"), s_axi_ctrl_ARREGION("s_axi_ctrl_ARREGION"), rp_axi_ctrl_ARREGION("rp_axi_ctrl_ARREGION"), s_axi_ctrl_ARQOS("s_axi_ctrl_ARQOS"), rp_axi_ctrl_ARQOS("rp_axi_ctrl_ARQOS"), s_axi_ctrl_RDATA("s_axi_ctrl_RDATA"), rp_axi_ctrl_RDATA("rp_axi_ctrl_RDATA"), s_axi_ctrl_RRESP("s_axi_ctrl_RRESP"), rp_axi_ctrl_RRESP("rp_axi_ctrl_RRESP"), s_interrupt_INTERRUPT("s_interrupt_INTERRUPT"), rp_interrupt_INTERRUPT("rp_interrupt_INTERRUPT"), s_reset_RST("s_reset_RST"), rp_reset_RST("rp_reset_RST"), decouple_status("decouple_status"), aclk("aclk"), s_axi_reg_awaddr("s_axi_reg_awaddr"), s_axi_reg_awvalid("s_axi_reg_awvalid"), s_axi_reg_awready("s_axi_reg_awready"), s_axi_reg_wdata("s_axi_reg_wdata"), s_axi_reg_wvalid("s_axi_reg_wvalid"), s_axi_reg_wready("s_axi_reg_wready"), s_axi_reg_bresp("s_axi_reg_bresp"), s_axi_reg_bvalid("s_axi_reg_bvalid"), s_axi_reg_bready("s_axi_reg_bready"), s_axi_reg_araddr("s_axi_reg_araddr"), s_axi_reg_arvalid("s_axi_reg_arvalid"), s_axi_reg_arready("s_axi_reg_arready"), s_axi_reg_rdata("s_axi_reg_rdata"), s_axi_reg_rresp("s_axi_reg_rresp"), s_axi_reg_rvalid("s_axi_reg_rvalid"), s_axi_reg_rready("s_axi_reg_rready"), s_axi_reg_aresetn("s_axi_reg_aresetn")
{

  // initialize pins
  mp_impl->s_interrupt_INTERRUPT(s_interrupt_INTERRUPT);
  mp_impl->rp_interrupt_INTERRUPT(rp_interrupt_INTERRUPT);
  mp_impl->s_reset_RST(s_reset_RST);
  mp_impl->rp_reset_RST(rp_reset_RST);
  mp_impl->decouple_status(decouple_status);
  mp_impl->aclk(aclk);
  mp_impl->s_axi_reg_aresetn(s_axi_reg_aresetn);

  // initialize transactors
  mp_s_stream_a_transactor = NULL;
  mp_rp_stream_a_transactor = NULL;
  mp_s_stream_b_transactor = NULL;
  mp_rp_stream_b_transactor = NULL;
  mp_s_stream_c_transactor = NULL;
  mp_rp_stream_c_transactor = NULL;
  mp_s_axi_ctrl_transactor = NULL;
  mp_rp_axi_ctrl_transactor = NULL;
  mp_s_axi_reg_transactor = NULL;

  // initialize socket stubs

}

void design_1_dfx_decoupler_0_0::before_end_of_elaboration()
{
  // configure 's_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_a' transactor parameters
    xsc::common_cpp::properties s_stream_a_transactor_param_props;
    s_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_a_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_a_transactor", s_stream_a_transactor_param_props);

    // s_stream_a' transactor ports

    mp_s_stream_a_transactor->TVALID(s_stream_a_TVALID);
    mp_s_stream_a_transactor->TREADY(s_stream_a_TREADY);
    mp_s_stream_a_transactor->TDATA(s_stream_a_TDATA);
    mp_s_stream_a_transactor->TLAST(s_stream_a_TLAST);
    mp_s_stream_a_transactor->TKEEP(s_stream_a_TKEEP);
    mp_s_stream_a_transactor->CLK(aclk);
    m_s_stream_a_transactor_rst_signal.write(1);
    mp_s_stream_a_transactor->RST(m_s_stream_a_transactor_rst_signal);

    // s_stream_a' transactor sockets

    mp_impl->S00_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_a' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_a_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_a' transactor parameters
    xsc::common_cpp::properties rp_stream_a_transactor_param_props;
    rp_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_a_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_a_transactor", rp_stream_a_transactor_param_props);

    // rp_stream_a' transactor ports

    mp_rp_stream_a_transactor->TVALID(rp_stream_a_TVALID);
    mp_rp_stream_a_transactor->TREADY(rp_stream_a_TREADY);
    mp_rp_stream_a_transactor->TDATA(rp_stream_a_TDATA);
    mp_rp_stream_a_transactor->TLAST(rp_stream_a_TLAST);
    mp_rp_stream_a_transactor->TKEEP(rp_stream_a_TKEEP);
    mp_rp_stream_a_transactor->CLK(aclk);
    m_rp_stream_a_transactor_rst_signal.write(1);
    mp_rp_stream_a_transactor->RST(m_rp_stream_a_transactor_rst_signal);

    // rp_stream_a' transactor sockets

    mp_impl->M00_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_a_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_b' transactor parameters
    xsc::common_cpp::properties s_stream_b_transactor_param_props;
    s_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_b_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_b_transactor", s_stream_b_transactor_param_props);

    // s_stream_b' transactor ports

    mp_s_stream_b_transactor->TVALID(s_stream_b_TVALID);
    mp_s_stream_b_transactor->TREADY(s_stream_b_TREADY);
    mp_s_stream_b_transactor->TDATA(s_stream_b_TDATA);
    mp_s_stream_b_transactor->TLAST(s_stream_b_TLAST);
    mp_s_stream_b_transactor->TKEEP(s_stream_b_TKEEP);
    mp_s_stream_b_transactor->CLK(aclk);
    m_s_stream_b_transactor_rst_signal.write(1);
    mp_s_stream_b_transactor->RST(m_s_stream_b_transactor_rst_signal);

    // s_stream_b' transactor sockets

    mp_impl->S01_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_b' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_b_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_b' transactor parameters
    xsc::common_cpp::properties rp_stream_b_transactor_param_props;
    rp_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_b_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_b_transactor", rp_stream_b_transactor_param_props);

    // rp_stream_b' transactor ports

    mp_rp_stream_b_transactor->TVALID(rp_stream_b_TVALID);
    mp_rp_stream_b_transactor->TREADY(rp_stream_b_TREADY);
    mp_rp_stream_b_transactor->TDATA(rp_stream_b_TDATA);
    mp_rp_stream_b_transactor->TLAST(rp_stream_b_TLAST);
    mp_rp_stream_b_transactor->TKEEP(rp_stream_b_TKEEP);
    mp_rp_stream_b_transactor->CLK(aclk);
    m_rp_stream_b_transactor_rst_signal.write(1);
    mp_rp_stream_b_transactor->RST(m_rp_stream_b_transactor_rst_signal);

    // rp_stream_b' transactor sockets

    mp_impl->M01_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_b_transactor->socket));
  }
  else
  {
  }

  // configure 's_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_stream_c' transactor parameters
    xsc::common_cpp::properties s_stream_c_transactor_param_props;
    s_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_c_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("s_stream_c_transactor", s_stream_c_transactor_param_props);

    // s_stream_c' transactor ports

    mp_s_stream_c_transactor->TVALID(s_stream_c_TVALID);
    mp_s_stream_c_transactor->TREADY(s_stream_c_TREADY);
    mp_s_stream_c_transactor->TDATA(s_stream_c_TDATA);
    mp_s_stream_c_transactor->TUSER(s_stream_c_TUSER);
    mp_s_stream_c_transactor->TLAST(s_stream_c_TLAST);
    mp_s_stream_c_transactor->TID(s_stream_c_TID);
    mp_s_stream_c_transactor->TDEST(s_stream_c_TDEST);
    mp_s_stream_c_transactor->TSTRB(s_stream_c_TSTRB);
    mp_s_stream_c_transactor->TKEEP(s_stream_c_TKEEP);
    mp_s_stream_c_transactor->CLK(aclk);
    m_s_stream_c_transactor_rst_signal.write(1);
    mp_s_stream_c_transactor->RST(m_s_stream_c_transactor_rst_signal);

    // s_stream_c' transactor sockets

    mp_impl->M02_AXIS_INITIATOR_SOCKET->bind(*(mp_s_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 'rp_stream_c' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_c_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_stream_c' transactor parameters
    xsc::common_cpp::properties rp_stream_c_transactor_param_props;
    rp_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_c_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("rp_stream_c_transactor", rp_stream_c_transactor_param_props);

    // rp_stream_c' transactor ports

    mp_rp_stream_c_transactor->TVALID(rp_stream_c_TVALID);
    mp_rp_stream_c_transactor->TREADY(rp_stream_c_TREADY);
    mp_rp_stream_c_transactor->TDATA(rp_stream_c_TDATA);
    mp_rp_stream_c_transactor->TUSER(rp_stream_c_TUSER);
    mp_rp_stream_c_transactor->TLAST(rp_stream_c_TLAST);
    mp_rp_stream_c_transactor->TID(rp_stream_c_TID);
    mp_rp_stream_c_transactor->TDEST(rp_stream_c_TDEST);
    mp_rp_stream_c_transactor->TSTRB(rp_stream_c_TSTRB);
    mp_rp_stream_c_transactor->TKEEP(rp_stream_c_TKEEP);
    mp_rp_stream_c_transactor->CLK(aclk);
    m_rp_stream_c_transactor_rst_signal.write(1);
    mp_rp_stream_c_transactor->RST(m_rp_stream_c_transactor_rst_signal);

    // rp_stream_c' transactor sockets

    mp_impl->S02_AXIS_TARGET_SOCKET->bind(*(mp_rp_stream_c_transactor->socket));
  }
  else
  {
  }

  // configure 's_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_ctrl' transactor parameters
    xsc::common_cpp::properties s_axi_ctrl_transactor_param_props;
    s_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    s_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    s_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_axi_ctrl_transactor = new xtlm::xaximm_pin2xtlm_t<32,16,1,1,1,1,1,1>("s_axi_ctrl_transactor", s_axi_ctrl_transactor_param_props);

    // s_axi_ctrl' transactor ports

    mp_s_axi_ctrl_transactor->ARVALID(s_axi_ctrl_ARVALID);
    mp_s_axi_ctrl_transactor->ARREADY(s_axi_ctrl_ARREADY);
    mp_s_axi_ctrl_transactor->AWVALID(s_axi_ctrl_AWVALID);
    mp_s_axi_ctrl_transactor->AWREADY(s_axi_ctrl_AWREADY);
    mp_s_axi_ctrl_transactor->BVALID(s_axi_ctrl_BVALID);
    mp_s_axi_ctrl_transactor->BREADY(s_axi_ctrl_BREADY);
    mp_s_axi_ctrl_transactor->RVALID(s_axi_ctrl_RVALID);
    mp_s_axi_ctrl_transactor->RREADY(s_axi_ctrl_RREADY);
    mp_s_axi_ctrl_transactor->WVALID(s_axi_ctrl_WVALID);
    mp_s_axi_ctrl_transactor->WREADY(s_axi_ctrl_WREADY);
    mp_s_axi_ctrl_transactor->AWADDR(s_axi_ctrl_AWADDR);
    mp_s_axi_ctrl_transactor->AWPROT(s_axi_ctrl_AWPROT);
    mp_s_axi_ctrl_transactor->AWREGION(s_axi_ctrl_AWREGION);
    mp_s_axi_ctrl_transactor->AWQOS(s_axi_ctrl_AWQOS);
    mp_s_axi_ctrl_transactor->WDATA(s_axi_ctrl_WDATA);
    mp_s_axi_ctrl_transactor->WSTRB(s_axi_ctrl_WSTRB);
    mp_s_axi_ctrl_transactor->BRESP(s_axi_ctrl_BRESP);
    mp_s_axi_ctrl_transactor->ARADDR(s_axi_ctrl_ARADDR);
    mp_s_axi_ctrl_transactor->ARPROT(s_axi_ctrl_ARPROT);
    mp_s_axi_ctrl_transactor->ARREGION(s_axi_ctrl_ARREGION);
    mp_s_axi_ctrl_transactor->ARQOS(s_axi_ctrl_ARQOS);
    mp_s_axi_ctrl_transactor->RDATA(s_axi_ctrl_RDATA);
    mp_s_axi_ctrl_transactor->RRESP(s_axi_ctrl_RRESP);
    mp_s_axi_ctrl_transactor->CLK(aclk);
    m_s_axi_ctrl_transactor_rst_signal.write(1);
    mp_s_axi_ctrl_transactor->RST(m_s_axi_ctrl_transactor_rst_signal);

    // s_axi_ctrl' transactor sockets

    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 'rp_axi_ctrl' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_axi_ctrl_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 'rp_axi_ctrl' transactor parameters
    xsc::common_cpp::properties rp_axi_ctrl_transactor_param_props;
    rp_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    rp_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    rp_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    rp_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_axi_ctrl_transactor = new xtlm::xaximm_xtlm2pin_t<32,16,1,1,1,1,1,1>("rp_axi_ctrl_transactor", rp_axi_ctrl_transactor_param_props);

    // rp_axi_ctrl' transactor ports

    mp_rp_axi_ctrl_transactor->ARVALID(rp_axi_ctrl_ARVALID);
    mp_rp_axi_ctrl_transactor->ARREADY(rp_axi_ctrl_ARREADY);
    mp_rp_axi_ctrl_transactor->AWVALID(rp_axi_ctrl_AWVALID);
    mp_rp_axi_ctrl_transactor->AWREADY(rp_axi_ctrl_AWREADY);
    mp_rp_axi_ctrl_transactor->BVALID(rp_axi_ctrl_BVALID);
    mp_rp_axi_ctrl_transactor->BREADY(rp_axi_ctrl_BREADY);
    mp_rp_axi_ctrl_transactor->RVALID(rp_axi_ctrl_RVALID);
    mp_rp_axi_ctrl_transactor->RREADY(rp_axi_ctrl_RREADY);
    mp_rp_axi_ctrl_transactor->WVALID(rp_axi_ctrl_WVALID);
    mp_rp_axi_ctrl_transactor->WREADY(rp_axi_ctrl_WREADY);
    mp_rp_axi_ctrl_transactor->AWADDR(rp_axi_ctrl_AWADDR);
    mp_rp_axi_ctrl_transactor->AWPROT(rp_axi_ctrl_AWPROT);
    mp_rp_axi_ctrl_transactor->AWREGION(rp_axi_ctrl_AWREGION);
    mp_rp_axi_ctrl_transactor->AWQOS(rp_axi_ctrl_AWQOS);
    mp_rp_axi_ctrl_transactor->WDATA(rp_axi_ctrl_WDATA);
    mp_rp_axi_ctrl_transactor->WSTRB(rp_axi_ctrl_WSTRB);
    mp_rp_axi_ctrl_transactor->BRESP(rp_axi_ctrl_BRESP);
    mp_rp_axi_ctrl_transactor->ARADDR(rp_axi_ctrl_ARADDR);
    mp_rp_axi_ctrl_transactor->ARPROT(rp_axi_ctrl_ARPROT);
    mp_rp_axi_ctrl_transactor->ARREGION(rp_axi_ctrl_ARREGION);
    mp_rp_axi_ctrl_transactor->ARQOS(rp_axi_ctrl_ARQOS);
    mp_rp_axi_ctrl_transactor->RDATA(rp_axi_ctrl_RDATA);
    mp_rp_axi_ctrl_transactor->RRESP(rp_axi_ctrl_RRESP);
    mp_rp_axi_ctrl_transactor->CLK(aclk);
    m_rp_axi_ctrl_transactor_rst_signal.write(1);
    mp_rp_axi_ctrl_transactor->RST(m_rp_axi_ctrl_transactor_rst_signal);

    // rp_axi_ctrl' transactor sockets

    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
  }
  else
  {
  }

  // configure 's_axi_reg' transactor

  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_reg_TLM_MODE") != 1)
  {
    // Instantiate Socket Stubs

  // 's_axi_reg' transactor parameters
    xsc::common_cpp::properties s_axi_reg_transactor_param_props;
    s_axi_reg_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_reg_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_reg_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ADDR_WIDTH", "1");
    s_axi_reg_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_PROT", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_QOS", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_REGION", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_WSTRB", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_reg_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_reg_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_reg_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_reg_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_reg_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_reg_transactor_param_props.addString("CLK_DOMAIN", "design_1_zynq_ultra_ps_e_0_0_pl_clk0");

    mp_s_axi_reg_transactor = new xtlm::xaximm_pin2xtlm_t<32,1,1,1,1,1,1,1>("s_axi_reg_transactor", s_axi_reg_transactor_param_props);

    // s_axi_reg' transactor ports

    mp_s_axi_reg_transactor->AWADDR(s_axi_reg_awaddr);
    mp_s_axi_reg_transactor->AWVALID(s_axi_reg_awvalid);
    mp_s_axi_reg_transactor->AWREADY(s_axi_reg_awready);
    mp_s_axi_reg_transactor->WDATA(s_axi_reg_wdata);
    mp_s_axi_reg_transactor->WVALID(s_axi_reg_wvalid);
    mp_s_axi_reg_transactor->WREADY(s_axi_reg_wready);
    mp_s_axi_reg_transactor->BRESP(s_axi_reg_bresp);
    mp_s_axi_reg_transactor->BVALID(s_axi_reg_bvalid);
    mp_s_axi_reg_transactor->BREADY(s_axi_reg_bready);
    mp_s_axi_reg_transactor->ARADDR(s_axi_reg_araddr);
    mp_s_axi_reg_transactor->ARVALID(s_axi_reg_arvalid);
    mp_s_axi_reg_transactor->ARREADY(s_axi_reg_arready);
    mp_s_axi_reg_transactor->RDATA(s_axi_reg_rdata);
    mp_s_axi_reg_transactor->RRESP(s_axi_reg_rresp);
    mp_s_axi_reg_transactor->RVALID(s_axi_reg_rvalid);
    mp_s_axi_reg_transactor->RREADY(s_axi_reg_rready);
    mp_s_axi_reg_transactor->CLK(aclk);
    m_s_axi_reg_transactor_rst_signal.write(1);
    mp_s_axi_reg_transactor->RST(m_s_axi_reg_transactor_rst_signal);

    // s_axi_reg' transactor sockets

    mp_impl->axilite_wr_socket->bind(*(mp_s_axi_reg_transactor->wr_socket));
    mp_impl->axilite_rd_socket->bind(*(mp_s_axi_reg_transactor->rd_socket));
  }
  else
  {
  }

}

#endif // RIVIERA




#ifdef VCSSYSTEMC
design_1_dfx_decoupler_0_0::design_1_dfx_decoupler_0_0(const sc_core::sc_module_name& nm) : design_1_dfx_decoupler_0_0_sc(nm),  s_stream_a_TVALID("s_stream_a_TVALID"), rp_stream_a_TVALID("rp_stream_a_TVALID"), s_stream_a_TREADY("s_stream_a_TREADY"), rp_stream_a_TREADY("rp_stream_a_TREADY"), s_stream_a_TDATA("s_stream_a_TDATA"), rp_stream_a_TDATA("rp_stream_a_TDATA"), s_stream_a_TLAST("s_stream_a_TLAST"), rp_stream_a_TLAST("rp_stream_a_TLAST"), s_stream_a_TKEEP("s_stream_a_TKEEP"), rp_stream_a_TKEEP("rp_stream_a_TKEEP"), s_stream_b_TVALID("s_stream_b_TVALID"), rp_stream_b_TVALID("rp_stream_b_TVALID"), s_stream_b_TREADY("s_stream_b_TREADY"), rp_stream_b_TREADY("rp_stream_b_TREADY"), s_stream_b_TDATA("s_stream_b_TDATA"), rp_stream_b_TDATA("rp_stream_b_TDATA"), s_stream_b_TLAST("s_stream_b_TLAST"), rp_stream_b_TLAST("rp_stream_b_TLAST"), s_stream_b_TKEEP("s_stream_b_TKEEP"), rp_stream_b_TKEEP("rp_stream_b_TKEEP"), s_stream_c_TVALID("s_stream_c_TVALID"), rp_stream_c_TVALID("rp_stream_c_TVALID"), s_stream_c_TREADY("s_stream_c_TREADY"), rp_stream_c_TREADY("rp_stream_c_TREADY"), s_stream_c_TDATA("s_stream_c_TDATA"), rp_stream_c_TDATA("rp_stream_c_TDATA"), s_stream_c_TUSER("s_stream_c_TUSER"), rp_stream_c_TUSER("rp_stream_c_TUSER"), s_stream_c_TLAST("s_stream_c_TLAST"), rp_stream_c_TLAST("rp_stream_c_TLAST"), s_stream_c_TID("s_stream_c_TID"), rp_stream_c_TID("rp_stream_c_TID"), s_stream_c_TDEST("s_stream_c_TDEST"), rp_stream_c_TDEST("rp_stream_c_TDEST"), s_stream_c_TSTRB("s_stream_c_TSTRB"), rp_stream_c_TSTRB("rp_stream_c_TSTRB"), s_stream_c_TKEEP("s_stream_c_TKEEP"), rp_stream_c_TKEEP("rp_stream_c_TKEEP"), s_axi_ctrl_ARVALID("s_axi_ctrl_ARVALID"), rp_axi_ctrl_ARVALID("rp_axi_ctrl_ARVALID"), s_axi_ctrl_ARREADY("s_axi_ctrl_ARREADY"), rp_axi_ctrl_ARREADY("rp_axi_ctrl_ARREADY"), s_axi_ctrl_AWVALID("s_axi_ctrl_AWVALID"), rp_axi_ctrl_AWVALID("rp_axi_ctrl_AWVALID"), s_axi_ctrl_AWREADY("s_axi_ctrl_AWREADY"), rp_axi_ctrl_AWREADY("rp_axi_ctrl_AWREADY"), s_axi_ctrl_BVALID("s_axi_ctrl_BVALID"), rp_axi_ctrl_BVALID("rp_axi_ctrl_BVALID"), s_axi_ctrl_BREADY("s_axi_ctrl_BREADY"), rp_axi_ctrl_BREADY("rp_axi_ctrl_BREADY"), s_axi_ctrl_RVALID("s_axi_ctrl_RVALID"), rp_axi_ctrl_RVALID("rp_axi_ctrl_RVALID"), s_axi_ctrl_RREADY("s_axi_ctrl_RREADY"), rp_axi_ctrl_RREADY("rp_axi_ctrl_RREADY"), s_axi_ctrl_WVALID("s_axi_ctrl_WVALID"), rp_axi_ctrl_WVALID("rp_axi_ctrl_WVALID"), s_axi_ctrl_WREADY("s_axi_ctrl_WREADY"), rp_axi_ctrl_WREADY("rp_axi_ctrl_WREADY"), s_axi_ctrl_AWADDR("s_axi_ctrl_AWADDR"), rp_axi_ctrl_AWADDR("rp_axi_ctrl_AWADDR"), s_axi_ctrl_AWPROT("s_axi_ctrl_AWPROT"), rp_axi_ctrl_AWPROT("rp_axi_ctrl_AWPROT"), s_axi_ctrl_AWREGION("s_axi_ctrl_AWREGION"), rp_axi_ctrl_AWREGION("rp_axi_ctrl_AWREGION"), s_axi_ctrl_AWQOS("s_axi_ctrl_AWQOS"), rp_axi_ctrl_AWQOS("rp_axi_ctrl_AWQOS"), s_axi_ctrl_WDATA("s_axi_ctrl_WDATA"), rp_axi_ctrl_WDATA("rp_axi_ctrl_WDATA"), s_axi_ctrl_WSTRB("s_axi_ctrl_WSTRB"), rp_axi_ctrl_WSTRB("rp_axi_ctrl_WSTRB"), s_axi_ctrl_BRESP("s_axi_ctrl_BRESP"), rp_axi_ctrl_BRESP("rp_axi_ctrl_BRESP"), s_axi_ctrl_ARADDR("s_axi_ctrl_ARADDR"), rp_axi_ctrl_ARADDR("rp_axi_ctrl_ARADDR"), s_axi_ctrl_ARPROT("s_axi_ctrl_ARPROT"), rp_axi_ctrl_ARPROT("rp_axi_ctrl_ARPROT"), s_axi_ctrl_ARREGION("s_axi_ctrl_ARREGION"), rp_axi_ctrl_ARREGION("rp_axi_ctrl_ARREGION"), s_axi_ctrl_ARQOS("s_axi_ctrl_ARQOS"), rp_axi_ctrl_ARQOS("rp_axi_ctrl_ARQOS"), s_axi_ctrl_RDATA("s_axi_ctrl_RDATA"), rp_axi_ctrl_RDATA("rp_axi_ctrl_RDATA"), s_axi_ctrl_RRESP("s_axi_ctrl_RRESP"), rp_axi_ctrl_RRESP("rp_axi_ctrl_RRESP"), s_interrupt_INTERRUPT("s_interrupt_INTERRUPT"), rp_interrupt_INTERRUPT("rp_interrupt_INTERRUPT"), s_reset_RST("s_reset_RST"), rp_reset_RST("rp_reset_RST"), decouple_status("decouple_status"), aclk("aclk"), s_axi_reg_awaddr("s_axi_reg_awaddr"), s_axi_reg_awvalid("s_axi_reg_awvalid"), s_axi_reg_awready("s_axi_reg_awready"), s_axi_reg_wdata("s_axi_reg_wdata"), s_axi_reg_wvalid("s_axi_reg_wvalid"), s_axi_reg_wready("s_axi_reg_wready"), s_axi_reg_bresp("s_axi_reg_bresp"), s_axi_reg_bvalid("s_axi_reg_bvalid"), s_axi_reg_bready("s_axi_reg_bready"), s_axi_reg_araddr("s_axi_reg_araddr"), s_axi_reg_arvalid("s_axi_reg_arvalid"), s_axi_reg_arready("s_axi_reg_arready"), s_axi_reg_rdata("s_axi_reg_rdata"), s_axi_reg_rresp("s_axi_reg_rresp"), s_axi_reg_rvalid("s_axi_reg_rvalid"), s_axi_reg_rready("s_axi_reg_rready"), s_axi_reg_aresetn("s_axi_reg_aresetn")
{
  // initialize pins
  mp_impl->s_interrupt_INTERRUPT(s_interrupt_INTERRUPT);
  mp_impl->rp_interrupt_INTERRUPT(rp_interrupt_INTERRUPT);
  mp_impl->s_reset_RST(s_reset_RST);
  mp_impl->rp_reset_RST(rp_reset_RST);
  mp_impl->decouple_status(decouple_status);
  mp_impl->aclk(aclk);
  mp_impl->s_axi_reg_aresetn(s_axi_reg_aresetn);

  // initialize transactors
  mp_s_stream_a_transactor = NULL;
  mp_rp_stream_a_transactor = NULL;
  mp_s_stream_b_transactor = NULL;
  mp_rp_stream_b_transactor = NULL;
  mp_s_stream_c_transactor = NULL;
  mp_rp_stream_c_transactor = NULL;
  mp_s_axi_ctrl_transactor = NULL;
  mp_rp_axi_ctrl_transactor = NULL;
  mp_s_axi_reg_transactor = NULL;

  // Instantiate Socket Stubs

  // configure s_stream_a_transactor
    xsc::common_cpp::properties s_stream_a_transactor_param_props;
    s_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_a_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_a_transactor", s_stream_a_transactor_param_props);
  mp_s_stream_a_transactor->TVALID(s_stream_a_TVALID);
  mp_s_stream_a_transactor->TREADY(s_stream_a_TREADY);
  mp_s_stream_a_transactor->TDATA(s_stream_a_TDATA);
  mp_s_stream_a_transactor->TLAST(s_stream_a_TLAST);
  mp_s_stream_a_transactor->TKEEP(s_stream_a_TKEEP);
  mp_s_stream_a_transactor->CLK(aclk);
  m_s_stream_a_transactor_rst_signal.write(1);
  mp_s_stream_a_transactor->RST(m_s_stream_a_transactor_rst_signal);
  // configure rp_stream_a_transactor
    xsc::common_cpp::properties rp_stream_a_transactor_param_props;
    rp_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_a_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_a_transactor", rp_stream_a_transactor_param_props);
  mp_rp_stream_a_transactor->TVALID(rp_stream_a_TVALID);
  mp_rp_stream_a_transactor->TREADY(rp_stream_a_TREADY);
  mp_rp_stream_a_transactor->TDATA(rp_stream_a_TDATA);
  mp_rp_stream_a_transactor->TLAST(rp_stream_a_TLAST);
  mp_rp_stream_a_transactor->TKEEP(rp_stream_a_TKEEP);
  mp_rp_stream_a_transactor->CLK(aclk);
  m_rp_stream_a_transactor_rst_signal.write(1);
  mp_rp_stream_a_transactor->RST(m_rp_stream_a_transactor_rst_signal);
  // configure s_stream_b_transactor
    xsc::common_cpp::properties s_stream_b_transactor_param_props;
    s_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_b_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_b_transactor", s_stream_b_transactor_param_props);
  mp_s_stream_b_transactor->TVALID(s_stream_b_TVALID);
  mp_s_stream_b_transactor->TREADY(s_stream_b_TREADY);
  mp_s_stream_b_transactor->TDATA(s_stream_b_TDATA);
  mp_s_stream_b_transactor->TLAST(s_stream_b_TLAST);
  mp_s_stream_b_transactor->TKEEP(s_stream_b_TKEEP);
  mp_s_stream_b_transactor->CLK(aclk);
  m_s_stream_b_transactor_rst_signal.write(1);
  mp_s_stream_b_transactor->RST(m_s_stream_b_transactor_rst_signal);
  // configure rp_stream_b_transactor
    xsc::common_cpp::properties rp_stream_b_transactor_param_props;
    rp_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_b_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_b_transactor", rp_stream_b_transactor_param_props);
  mp_rp_stream_b_transactor->TVALID(rp_stream_b_TVALID);
  mp_rp_stream_b_transactor->TREADY(rp_stream_b_TREADY);
  mp_rp_stream_b_transactor->TDATA(rp_stream_b_TDATA);
  mp_rp_stream_b_transactor->TLAST(rp_stream_b_TLAST);
  mp_rp_stream_b_transactor->TKEEP(rp_stream_b_TKEEP);
  mp_rp_stream_b_transactor->CLK(aclk);
  m_rp_stream_b_transactor_rst_signal.write(1);
  mp_rp_stream_b_transactor->RST(m_rp_stream_b_transactor_rst_signal);
  // configure s_stream_c_transactor
    xsc::common_cpp::properties s_stream_c_transactor_param_props;
    s_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_c_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("s_stream_c_transactor", s_stream_c_transactor_param_props);
  mp_s_stream_c_transactor->TVALID(s_stream_c_TVALID);
  mp_s_stream_c_transactor->TREADY(s_stream_c_TREADY);
  mp_s_stream_c_transactor->TDATA(s_stream_c_TDATA);
  mp_s_stream_c_transactor->TUSER(s_stream_c_TUSER);
  mp_s_stream_c_transactor->TLAST(s_stream_c_TLAST);
  mp_s_stream_c_transactor->TID(s_stream_c_TID);
  mp_s_stream_c_transactor->TDEST(s_stream_c_TDEST);
  mp_s_stream_c_transactor->TSTRB(s_stream_c_TSTRB);
  mp_s_stream_c_transactor->TKEEP(s_stream_c_TKEEP);
  mp_s_stream_c_transactor->CLK(aclk);
  m_s_stream_c_transactor_rst_signal.write(1);
  mp_s_stream_c_transactor->RST(m_s_stream_c_transactor_rst_signal);
  // configure rp_stream_c_transactor
    xsc::common_cpp::properties rp_stream_c_transactor_param_props;
    rp_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_c_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("rp_stream_c_transactor", rp_stream_c_transactor_param_props);
  mp_rp_stream_c_transactor->TVALID(rp_stream_c_TVALID);
  mp_rp_stream_c_transactor->TREADY(rp_stream_c_TREADY);
  mp_rp_stream_c_transactor->TDATA(rp_stream_c_TDATA);
  mp_rp_stream_c_transactor->TUSER(rp_stream_c_TUSER);
  mp_rp_stream_c_transactor->TLAST(rp_stream_c_TLAST);
  mp_rp_stream_c_transactor->TID(rp_stream_c_TID);
  mp_rp_stream_c_transactor->TDEST(rp_stream_c_TDEST);
  mp_rp_stream_c_transactor->TSTRB(rp_stream_c_TSTRB);
  mp_rp_stream_c_transactor->TKEEP(rp_stream_c_TKEEP);
  mp_rp_stream_c_transactor->CLK(aclk);
  m_rp_stream_c_transactor_rst_signal.write(1);
  mp_rp_stream_c_transactor->RST(m_rp_stream_c_transactor_rst_signal);
  // configure s_axi_ctrl_transactor
    xsc::common_cpp::properties s_axi_ctrl_transactor_param_props;
    s_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    s_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    s_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_axi_ctrl_transactor = new xtlm::xaximm_pin2xtlm_t<32,16,1,1,1,1,1,1>("s_axi_ctrl_transactor", s_axi_ctrl_transactor_param_props);
  mp_s_axi_ctrl_transactor->ARVALID(s_axi_ctrl_ARVALID);
  mp_s_axi_ctrl_transactor->ARREADY(s_axi_ctrl_ARREADY);
  mp_s_axi_ctrl_transactor->AWVALID(s_axi_ctrl_AWVALID);
  mp_s_axi_ctrl_transactor->AWREADY(s_axi_ctrl_AWREADY);
  mp_s_axi_ctrl_transactor->BVALID(s_axi_ctrl_BVALID);
  mp_s_axi_ctrl_transactor->BREADY(s_axi_ctrl_BREADY);
  mp_s_axi_ctrl_transactor->RVALID(s_axi_ctrl_RVALID);
  mp_s_axi_ctrl_transactor->RREADY(s_axi_ctrl_RREADY);
  mp_s_axi_ctrl_transactor->WVALID(s_axi_ctrl_WVALID);
  mp_s_axi_ctrl_transactor->WREADY(s_axi_ctrl_WREADY);
  mp_s_axi_ctrl_transactor->AWADDR(s_axi_ctrl_AWADDR);
  mp_s_axi_ctrl_transactor->AWPROT(s_axi_ctrl_AWPROT);
  mp_s_axi_ctrl_transactor->AWREGION(s_axi_ctrl_AWREGION);
  mp_s_axi_ctrl_transactor->AWQOS(s_axi_ctrl_AWQOS);
  mp_s_axi_ctrl_transactor->WDATA(s_axi_ctrl_WDATA);
  mp_s_axi_ctrl_transactor->WSTRB(s_axi_ctrl_WSTRB);
  mp_s_axi_ctrl_transactor->BRESP(s_axi_ctrl_BRESP);
  mp_s_axi_ctrl_transactor->ARADDR(s_axi_ctrl_ARADDR);
  mp_s_axi_ctrl_transactor->ARPROT(s_axi_ctrl_ARPROT);
  mp_s_axi_ctrl_transactor->ARREGION(s_axi_ctrl_ARREGION);
  mp_s_axi_ctrl_transactor->ARQOS(s_axi_ctrl_ARQOS);
  mp_s_axi_ctrl_transactor->RDATA(s_axi_ctrl_RDATA);
  mp_s_axi_ctrl_transactor->RRESP(s_axi_ctrl_RRESP);
  mp_s_axi_ctrl_transactor->CLK(aclk);
  m_s_axi_ctrl_transactor_rst_signal.write(1);
  mp_s_axi_ctrl_transactor->RST(m_s_axi_ctrl_transactor_rst_signal);
  // configure rp_axi_ctrl_transactor
    xsc::common_cpp::properties rp_axi_ctrl_transactor_param_props;
    rp_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    rp_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    rp_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    rp_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_axi_ctrl_transactor = new xtlm::xaximm_xtlm2pin_t<32,16,1,1,1,1,1,1>("rp_axi_ctrl_transactor", rp_axi_ctrl_transactor_param_props);
  mp_rp_axi_ctrl_transactor->ARVALID(rp_axi_ctrl_ARVALID);
  mp_rp_axi_ctrl_transactor->ARREADY(rp_axi_ctrl_ARREADY);
  mp_rp_axi_ctrl_transactor->AWVALID(rp_axi_ctrl_AWVALID);
  mp_rp_axi_ctrl_transactor->AWREADY(rp_axi_ctrl_AWREADY);
  mp_rp_axi_ctrl_transactor->BVALID(rp_axi_ctrl_BVALID);
  mp_rp_axi_ctrl_transactor->BREADY(rp_axi_ctrl_BREADY);
  mp_rp_axi_ctrl_transactor->RVALID(rp_axi_ctrl_RVALID);
  mp_rp_axi_ctrl_transactor->RREADY(rp_axi_ctrl_RREADY);
  mp_rp_axi_ctrl_transactor->WVALID(rp_axi_ctrl_WVALID);
  mp_rp_axi_ctrl_transactor->WREADY(rp_axi_ctrl_WREADY);
  mp_rp_axi_ctrl_transactor->AWADDR(rp_axi_ctrl_AWADDR);
  mp_rp_axi_ctrl_transactor->AWPROT(rp_axi_ctrl_AWPROT);
  mp_rp_axi_ctrl_transactor->AWREGION(rp_axi_ctrl_AWREGION);
  mp_rp_axi_ctrl_transactor->AWQOS(rp_axi_ctrl_AWQOS);
  mp_rp_axi_ctrl_transactor->WDATA(rp_axi_ctrl_WDATA);
  mp_rp_axi_ctrl_transactor->WSTRB(rp_axi_ctrl_WSTRB);
  mp_rp_axi_ctrl_transactor->BRESP(rp_axi_ctrl_BRESP);
  mp_rp_axi_ctrl_transactor->ARADDR(rp_axi_ctrl_ARADDR);
  mp_rp_axi_ctrl_transactor->ARPROT(rp_axi_ctrl_ARPROT);
  mp_rp_axi_ctrl_transactor->ARREGION(rp_axi_ctrl_ARREGION);
  mp_rp_axi_ctrl_transactor->ARQOS(rp_axi_ctrl_ARQOS);
  mp_rp_axi_ctrl_transactor->RDATA(rp_axi_ctrl_RDATA);
  mp_rp_axi_ctrl_transactor->RRESP(rp_axi_ctrl_RRESP);
  mp_rp_axi_ctrl_transactor->CLK(aclk);
  m_rp_axi_ctrl_transactor_rst_signal.write(1);
  mp_rp_axi_ctrl_transactor->RST(m_rp_axi_ctrl_transactor_rst_signal);
  // configure s_axi_reg_transactor
    xsc::common_cpp::properties s_axi_reg_transactor_param_props;
    s_axi_reg_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_reg_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_reg_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ADDR_WIDTH", "1");
    s_axi_reg_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_PROT", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_QOS", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_REGION", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_WSTRB", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_reg_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_reg_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_reg_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_reg_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_reg_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_reg_transactor_param_props.addString("CLK_DOMAIN", "design_1_zynq_ultra_ps_e_0_0_pl_clk0");

    mp_s_axi_reg_transactor = new xtlm::xaximm_pin2xtlm_t<32,1,1,1,1,1,1,1>("s_axi_reg_transactor", s_axi_reg_transactor_param_props);
  mp_s_axi_reg_transactor->AWADDR(s_axi_reg_awaddr);
  mp_s_axi_reg_transactor->AWVALID(s_axi_reg_awvalid);
  mp_s_axi_reg_transactor->AWREADY(s_axi_reg_awready);
  mp_s_axi_reg_transactor->WDATA(s_axi_reg_wdata);
  mp_s_axi_reg_transactor->WVALID(s_axi_reg_wvalid);
  mp_s_axi_reg_transactor->WREADY(s_axi_reg_wready);
  mp_s_axi_reg_transactor->BRESP(s_axi_reg_bresp);
  mp_s_axi_reg_transactor->BVALID(s_axi_reg_bvalid);
  mp_s_axi_reg_transactor->BREADY(s_axi_reg_bready);
  mp_s_axi_reg_transactor->ARADDR(s_axi_reg_araddr);
  mp_s_axi_reg_transactor->ARVALID(s_axi_reg_arvalid);
  mp_s_axi_reg_transactor->ARREADY(s_axi_reg_arready);
  mp_s_axi_reg_transactor->RDATA(s_axi_reg_rdata);
  mp_s_axi_reg_transactor->RRESP(s_axi_reg_rresp);
  mp_s_axi_reg_transactor->RVALID(s_axi_reg_rvalid);
  mp_s_axi_reg_transactor->RREADY(s_axi_reg_rready);
  mp_s_axi_reg_transactor->CLK(aclk);
  m_s_axi_reg_transactor_rst_signal.write(1);
  mp_s_axi_reg_transactor->RST(m_s_axi_reg_transactor_rst_signal);

  // initialize transactors stubs
  s_stream_a_transactor_target_socket_stub = nullptr;
  rp_stream_a_transactor_initiator_socket_stub = nullptr;
  s_stream_b_transactor_target_socket_stub = nullptr;
  rp_stream_b_transactor_initiator_socket_stub = nullptr;
  s_stream_c_transactor_initiator_socket_stub = nullptr;
  rp_stream_c_transactor_target_socket_stub = nullptr;
  s_axi_ctrl_transactor_target_wr_socket_stub = nullptr;
  s_axi_ctrl_transactor_target_rd_socket_stub = nullptr;
  rp_axi_ctrl_transactor_initiator_wr_socket_stub = nullptr;
  rp_axi_ctrl_transactor_initiator_rd_socket_stub = nullptr;
  s_axi_reg_transactor_target_wr_socket_stub = nullptr;
  s_axi_reg_transactor_target_rd_socket_stub = nullptr;

}

void design_1_dfx_decoupler_0_0::before_end_of_elaboration()
{
  // configure 's_stream_a' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_a_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_a_transactor->socket));
  
  }
  else
  {
    s_stream_a_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    s_stream_a_transactor_target_socket_stub->bind(*(mp_s_stream_a_transactor->socket));
    mp_s_stream_a_transactor->disable_transactor();
  }

  // configure 'rp_stream_a' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_a_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_a_transactor->socket));
  
  }
  else
  {
    rp_stream_a_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    rp_stream_a_transactor_initiator_socket_stub->bind(*(mp_rp_stream_a_transactor->socket));
    mp_rp_stream_a_transactor->disable_transactor();
  }

  // configure 's_stream_b' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_b_TLM_MODE") != 1)
  {
    mp_impl->S01_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_b_transactor->socket));
  
  }
  else
  {
    s_stream_b_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    s_stream_b_transactor_target_socket_stub->bind(*(mp_s_stream_b_transactor->socket));
    mp_s_stream_b_transactor->disable_transactor();
  }

  // configure 'rp_stream_b' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_b_TLM_MODE") != 1)
  {
    mp_impl->M01_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_b_transactor->socket));
  
  }
  else
  {
    rp_stream_b_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    rp_stream_b_transactor_initiator_socket_stub->bind(*(mp_rp_stream_b_transactor->socket));
    mp_rp_stream_b_transactor->disable_transactor();
  }

  // configure 's_stream_c' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_c_TLM_MODE") != 1)
  {
    mp_impl->M02_AXIS_INITIATOR_SOCKET->bind(*(mp_s_stream_c_transactor->socket));
  
  }
  else
  {
    s_stream_c_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    s_stream_c_transactor_initiator_socket_stub->bind(*(mp_s_stream_c_transactor->socket));
    mp_s_stream_c_transactor->disable_transactor();
  }

  // configure 'rp_stream_c' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_c_TLM_MODE") != 1)
  {
    mp_impl->S02_AXIS_TARGET_SOCKET->bind(*(mp_rp_stream_c_transactor->socket));
  
  }
  else
  {
    rp_stream_c_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    rp_stream_c_transactor_target_socket_stub->bind(*(mp_rp_stream_c_transactor->socket));
    mp_rp_stream_c_transactor->disable_transactor();
  }

  // configure 's_axi_ctrl' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_ctrl_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
  
  }
  else
  {
    s_axi_ctrl_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_axi_ctrl_transactor_target_wr_socket_stub->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    s_axi_ctrl_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_axi_ctrl_transactor_target_rd_socket_stub->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
    mp_s_axi_ctrl_transactor->disable_transactor();
  }

  // configure 'rp_axi_ctrl' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_axi_ctrl_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
  
  }
  else
  {
    rp_axi_ctrl_transactor_initiator_wr_socket_stub = new xtlm::xtlm_aximm_initiator_stub("wr_socket",0);
    rp_axi_ctrl_transactor_initiator_wr_socket_stub->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    rp_axi_ctrl_transactor_initiator_rd_socket_stub = new xtlm::xtlm_aximm_initiator_stub("rd_socket",0);
    rp_axi_ctrl_transactor_initiator_rd_socket_stub->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
    mp_rp_axi_ctrl_transactor->disable_transactor();
  }

  // configure 's_axi_reg' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_reg_TLM_MODE") != 1)
  {
    mp_impl->axilite_wr_socket->bind(*(mp_s_axi_reg_transactor->wr_socket));
    mp_impl->axilite_rd_socket->bind(*(mp_s_axi_reg_transactor->rd_socket));
  
  }
  else
  {
    s_axi_reg_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_axi_reg_transactor_target_wr_socket_stub->bind(*(mp_s_axi_reg_transactor->wr_socket));
    s_axi_reg_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_axi_reg_transactor_target_rd_socket_stub->bind(*(mp_s_axi_reg_transactor->rd_socket));
    mp_s_axi_reg_transactor->disable_transactor();
  }

}

#endif // VCSSYSTEMC




#ifdef MTI_SYSTEMC
design_1_dfx_decoupler_0_0::design_1_dfx_decoupler_0_0(const sc_core::sc_module_name& nm) : design_1_dfx_decoupler_0_0_sc(nm),  s_stream_a_TVALID("s_stream_a_TVALID"), rp_stream_a_TVALID("rp_stream_a_TVALID"), s_stream_a_TREADY("s_stream_a_TREADY"), rp_stream_a_TREADY("rp_stream_a_TREADY"), s_stream_a_TDATA("s_stream_a_TDATA"), rp_stream_a_TDATA("rp_stream_a_TDATA"), s_stream_a_TLAST("s_stream_a_TLAST"), rp_stream_a_TLAST("rp_stream_a_TLAST"), s_stream_a_TKEEP("s_stream_a_TKEEP"), rp_stream_a_TKEEP("rp_stream_a_TKEEP"), s_stream_b_TVALID("s_stream_b_TVALID"), rp_stream_b_TVALID("rp_stream_b_TVALID"), s_stream_b_TREADY("s_stream_b_TREADY"), rp_stream_b_TREADY("rp_stream_b_TREADY"), s_stream_b_TDATA("s_stream_b_TDATA"), rp_stream_b_TDATA("rp_stream_b_TDATA"), s_stream_b_TLAST("s_stream_b_TLAST"), rp_stream_b_TLAST("rp_stream_b_TLAST"), s_stream_b_TKEEP("s_stream_b_TKEEP"), rp_stream_b_TKEEP("rp_stream_b_TKEEP"), s_stream_c_TVALID("s_stream_c_TVALID"), rp_stream_c_TVALID("rp_stream_c_TVALID"), s_stream_c_TREADY("s_stream_c_TREADY"), rp_stream_c_TREADY("rp_stream_c_TREADY"), s_stream_c_TDATA("s_stream_c_TDATA"), rp_stream_c_TDATA("rp_stream_c_TDATA"), s_stream_c_TUSER("s_stream_c_TUSER"), rp_stream_c_TUSER("rp_stream_c_TUSER"), s_stream_c_TLAST("s_stream_c_TLAST"), rp_stream_c_TLAST("rp_stream_c_TLAST"), s_stream_c_TID("s_stream_c_TID"), rp_stream_c_TID("rp_stream_c_TID"), s_stream_c_TDEST("s_stream_c_TDEST"), rp_stream_c_TDEST("rp_stream_c_TDEST"), s_stream_c_TSTRB("s_stream_c_TSTRB"), rp_stream_c_TSTRB("rp_stream_c_TSTRB"), s_stream_c_TKEEP("s_stream_c_TKEEP"), rp_stream_c_TKEEP("rp_stream_c_TKEEP"), s_axi_ctrl_ARVALID("s_axi_ctrl_ARVALID"), rp_axi_ctrl_ARVALID("rp_axi_ctrl_ARVALID"), s_axi_ctrl_ARREADY("s_axi_ctrl_ARREADY"), rp_axi_ctrl_ARREADY("rp_axi_ctrl_ARREADY"), s_axi_ctrl_AWVALID("s_axi_ctrl_AWVALID"), rp_axi_ctrl_AWVALID("rp_axi_ctrl_AWVALID"), s_axi_ctrl_AWREADY("s_axi_ctrl_AWREADY"), rp_axi_ctrl_AWREADY("rp_axi_ctrl_AWREADY"), s_axi_ctrl_BVALID("s_axi_ctrl_BVALID"), rp_axi_ctrl_BVALID("rp_axi_ctrl_BVALID"), s_axi_ctrl_BREADY("s_axi_ctrl_BREADY"), rp_axi_ctrl_BREADY("rp_axi_ctrl_BREADY"), s_axi_ctrl_RVALID("s_axi_ctrl_RVALID"), rp_axi_ctrl_RVALID("rp_axi_ctrl_RVALID"), s_axi_ctrl_RREADY("s_axi_ctrl_RREADY"), rp_axi_ctrl_RREADY("rp_axi_ctrl_RREADY"), s_axi_ctrl_WVALID("s_axi_ctrl_WVALID"), rp_axi_ctrl_WVALID("rp_axi_ctrl_WVALID"), s_axi_ctrl_WREADY("s_axi_ctrl_WREADY"), rp_axi_ctrl_WREADY("rp_axi_ctrl_WREADY"), s_axi_ctrl_AWADDR("s_axi_ctrl_AWADDR"), rp_axi_ctrl_AWADDR("rp_axi_ctrl_AWADDR"), s_axi_ctrl_AWPROT("s_axi_ctrl_AWPROT"), rp_axi_ctrl_AWPROT("rp_axi_ctrl_AWPROT"), s_axi_ctrl_AWREGION("s_axi_ctrl_AWREGION"), rp_axi_ctrl_AWREGION("rp_axi_ctrl_AWREGION"), s_axi_ctrl_AWQOS("s_axi_ctrl_AWQOS"), rp_axi_ctrl_AWQOS("rp_axi_ctrl_AWQOS"), s_axi_ctrl_WDATA("s_axi_ctrl_WDATA"), rp_axi_ctrl_WDATA("rp_axi_ctrl_WDATA"), s_axi_ctrl_WSTRB("s_axi_ctrl_WSTRB"), rp_axi_ctrl_WSTRB("rp_axi_ctrl_WSTRB"), s_axi_ctrl_BRESP("s_axi_ctrl_BRESP"), rp_axi_ctrl_BRESP("rp_axi_ctrl_BRESP"), s_axi_ctrl_ARADDR("s_axi_ctrl_ARADDR"), rp_axi_ctrl_ARADDR("rp_axi_ctrl_ARADDR"), s_axi_ctrl_ARPROT("s_axi_ctrl_ARPROT"), rp_axi_ctrl_ARPROT("rp_axi_ctrl_ARPROT"), s_axi_ctrl_ARREGION("s_axi_ctrl_ARREGION"), rp_axi_ctrl_ARREGION("rp_axi_ctrl_ARREGION"), s_axi_ctrl_ARQOS("s_axi_ctrl_ARQOS"), rp_axi_ctrl_ARQOS("rp_axi_ctrl_ARQOS"), s_axi_ctrl_RDATA("s_axi_ctrl_RDATA"), rp_axi_ctrl_RDATA("rp_axi_ctrl_RDATA"), s_axi_ctrl_RRESP("s_axi_ctrl_RRESP"), rp_axi_ctrl_RRESP("rp_axi_ctrl_RRESP"), s_interrupt_INTERRUPT("s_interrupt_INTERRUPT"), rp_interrupt_INTERRUPT("rp_interrupt_INTERRUPT"), s_reset_RST("s_reset_RST"), rp_reset_RST("rp_reset_RST"), decouple_status("decouple_status"), aclk("aclk"), s_axi_reg_awaddr("s_axi_reg_awaddr"), s_axi_reg_awvalid("s_axi_reg_awvalid"), s_axi_reg_awready("s_axi_reg_awready"), s_axi_reg_wdata("s_axi_reg_wdata"), s_axi_reg_wvalid("s_axi_reg_wvalid"), s_axi_reg_wready("s_axi_reg_wready"), s_axi_reg_bresp("s_axi_reg_bresp"), s_axi_reg_bvalid("s_axi_reg_bvalid"), s_axi_reg_bready("s_axi_reg_bready"), s_axi_reg_araddr("s_axi_reg_araddr"), s_axi_reg_arvalid("s_axi_reg_arvalid"), s_axi_reg_arready("s_axi_reg_arready"), s_axi_reg_rdata("s_axi_reg_rdata"), s_axi_reg_rresp("s_axi_reg_rresp"), s_axi_reg_rvalid("s_axi_reg_rvalid"), s_axi_reg_rready("s_axi_reg_rready"), s_axi_reg_aresetn("s_axi_reg_aresetn")
{
  // initialize pins
  mp_impl->s_interrupt_INTERRUPT(s_interrupt_INTERRUPT);
  mp_impl->rp_interrupt_INTERRUPT(rp_interrupt_INTERRUPT);
  mp_impl->s_reset_RST(s_reset_RST);
  mp_impl->rp_reset_RST(rp_reset_RST);
  mp_impl->decouple_status(decouple_status);
  mp_impl->aclk(aclk);
  mp_impl->s_axi_reg_aresetn(s_axi_reg_aresetn);

  // initialize transactors
  mp_s_stream_a_transactor = NULL;
  mp_rp_stream_a_transactor = NULL;
  mp_s_stream_b_transactor = NULL;
  mp_rp_stream_b_transactor = NULL;
  mp_s_stream_c_transactor = NULL;
  mp_rp_stream_c_transactor = NULL;
  mp_s_axi_ctrl_transactor = NULL;
  mp_rp_axi_ctrl_transactor = NULL;
  mp_s_axi_reg_transactor = NULL;

  // Instantiate Socket Stubs

  // configure s_stream_a_transactor
    xsc::common_cpp::properties s_stream_a_transactor_param_props;
    s_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_a_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_a_transactor", s_stream_a_transactor_param_props);
  mp_s_stream_a_transactor->TVALID(s_stream_a_TVALID);
  mp_s_stream_a_transactor->TREADY(s_stream_a_TREADY);
  mp_s_stream_a_transactor->TDATA(s_stream_a_TDATA);
  mp_s_stream_a_transactor->TLAST(s_stream_a_TLAST);
  mp_s_stream_a_transactor->TKEEP(s_stream_a_TKEEP);
  mp_s_stream_a_transactor->CLK(aclk);
  m_s_stream_a_transactor_rst_signal.write(1);
  mp_s_stream_a_transactor->RST(m_s_stream_a_transactor_rst_signal);
  // configure rp_stream_a_transactor
    xsc::common_cpp::properties rp_stream_a_transactor_param_props;
    rp_stream_a_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_a_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_a_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_a_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_a_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_a_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_a_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_a_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_a_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_a_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_a_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_a_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_a_transactor", rp_stream_a_transactor_param_props);
  mp_rp_stream_a_transactor->TVALID(rp_stream_a_TVALID);
  mp_rp_stream_a_transactor->TREADY(rp_stream_a_TREADY);
  mp_rp_stream_a_transactor->TDATA(rp_stream_a_TDATA);
  mp_rp_stream_a_transactor->TLAST(rp_stream_a_TLAST);
  mp_rp_stream_a_transactor->TKEEP(rp_stream_a_TKEEP);
  mp_rp_stream_a_transactor->CLK(aclk);
  m_rp_stream_a_transactor_rst_signal.write(1);
  mp_rp_stream_a_transactor->RST(m_rp_stream_a_transactor_rst_signal);
  // configure s_stream_b_transactor
    xsc::common_cpp::properties s_stream_b_transactor_param_props;
    s_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    s_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_b_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("s_stream_b_transactor", s_stream_b_transactor_param_props);
  mp_s_stream_b_transactor->TVALID(s_stream_b_TVALID);
  mp_s_stream_b_transactor->TREADY(s_stream_b_TREADY);
  mp_s_stream_b_transactor->TDATA(s_stream_b_TDATA);
  mp_s_stream_b_transactor->TLAST(s_stream_b_TLAST);
  mp_s_stream_b_transactor->TKEEP(s_stream_b_TKEEP);
  mp_s_stream_b_transactor->CLK(aclk);
  m_s_stream_b_transactor_rst_signal.write(1);
  mp_s_stream_b_transactor->RST(m_s_stream_b_transactor_rst_signal);
  // configure rp_stream_b_transactor
    xsc::common_cpp::properties rp_stream_b_transactor_param_props;
    rp_stream_b_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_b_transactor_param_props.addLong("TDEST_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TID_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TUSER_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TSTRB", "0");
    rp_stream_b_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_b_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_b_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_b_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_b_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_b_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_b_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_b_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_b_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_b_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("rp_stream_b_transactor", rp_stream_b_transactor_param_props);
  mp_rp_stream_b_transactor->TVALID(rp_stream_b_TVALID);
  mp_rp_stream_b_transactor->TREADY(rp_stream_b_TREADY);
  mp_rp_stream_b_transactor->TDATA(rp_stream_b_TDATA);
  mp_rp_stream_b_transactor->TLAST(rp_stream_b_TLAST);
  mp_rp_stream_b_transactor->TKEEP(rp_stream_b_TKEEP);
  mp_rp_stream_b_transactor->CLK(aclk);
  m_rp_stream_b_transactor_rst_signal.write(1);
  mp_rp_stream_b_transactor->RST(m_rp_stream_b_transactor_rst_signal);
  // configure s_stream_c_transactor
    xsc::common_cpp::properties s_stream_c_transactor_param_props;
    s_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    s_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    s_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    s_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    s_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    s_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    s_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    s_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    s_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_s_stream_c_transactor = new xtlm::xaxis_xtlm2pin_t<4,1,1,1,1,1>("s_stream_c_transactor", s_stream_c_transactor_param_props);
  mp_s_stream_c_transactor->TVALID(s_stream_c_TVALID);
  mp_s_stream_c_transactor->TREADY(s_stream_c_TREADY);
  mp_s_stream_c_transactor->TDATA(s_stream_c_TDATA);
  mp_s_stream_c_transactor->TUSER(s_stream_c_TUSER);
  mp_s_stream_c_transactor->TLAST(s_stream_c_TLAST);
  mp_s_stream_c_transactor->TID(s_stream_c_TID);
  mp_s_stream_c_transactor->TDEST(s_stream_c_TDEST);
  mp_s_stream_c_transactor->TSTRB(s_stream_c_TSTRB);
  mp_s_stream_c_transactor->TKEEP(s_stream_c_TKEEP);
  mp_s_stream_c_transactor->CLK(aclk);
  m_s_stream_c_transactor_rst_signal.write(1);
  mp_s_stream_c_transactor->RST(m_s_stream_c_transactor_rst_signal);
  // configure rp_stream_c_transactor
    xsc::common_cpp::properties rp_stream_c_transactor_param_props;
    rp_stream_c_transactor_param_props.addLong("TDATA_NUM_BYTES", "4");
    rp_stream_c_transactor_param_props.addLong("TDEST_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TID_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("TUSER_WIDTH", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TREADY", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TSTRB", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TKEEP", "1");
    rp_stream_c_transactor_param_props.addLong("HAS_TLAST", "1");
    rp_stream_c_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_stream_c_transactor_param_props.addLong("HAS_RESET", "0");
    rp_stream_c_transactor_param_props.addFloat("PHASE", "0.0");
    rp_stream_c_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_stream_c_transactor_param_props.addString("LAYERED_METADATA", "undef");
    rp_stream_c_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_1_WIDTH", "0");
    rp_stream_c_transactor_param_props.addLong("TSIDE_BAND_2_WIDTH", "0");

    mp_rp_stream_c_transactor = new xtlm::xaxis_pin2xtlm_t<4,1,1,1,1,1>("rp_stream_c_transactor", rp_stream_c_transactor_param_props);
  mp_rp_stream_c_transactor->TVALID(rp_stream_c_TVALID);
  mp_rp_stream_c_transactor->TREADY(rp_stream_c_TREADY);
  mp_rp_stream_c_transactor->TDATA(rp_stream_c_TDATA);
  mp_rp_stream_c_transactor->TUSER(rp_stream_c_TUSER);
  mp_rp_stream_c_transactor->TLAST(rp_stream_c_TLAST);
  mp_rp_stream_c_transactor->TID(rp_stream_c_TID);
  mp_rp_stream_c_transactor->TDEST(rp_stream_c_TDEST);
  mp_rp_stream_c_transactor->TSTRB(rp_stream_c_TSTRB);
  mp_rp_stream_c_transactor->TKEEP(rp_stream_c_TKEEP);
  mp_rp_stream_c_transactor->CLK(aclk);
  m_rp_stream_c_transactor_rst_signal.write(1);
  mp_rp_stream_c_transactor->RST(m_rp_stream_c_transactor_rst_signal);
  // configure s_axi_ctrl_transactor
    xsc::common_cpp::properties s_axi_ctrl_transactor_param_props;
    s_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    s_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    s_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_s_axi_ctrl_transactor = new xtlm::xaximm_pin2xtlm_t<32,16,1,1,1,1,1,1>("s_axi_ctrl_transactor", s_axi_ctrl_transactor_param_props);
  mp_s_axi_ctrl_transactor->ARVALID(s_axi_ctrl_ARVALID);
  mp_s_axi_ctrl_transactor->ARREADY(s_axi_ctrl_ARREADY);
  mp_s_axi_ctrl_transactor->AWVALID(s_axi_ctrl_AWVALID);
  mp_s_axi_ctrl_transactor->AWREADY(s_axi_ctrl_AWREADY);
  mp_s_axi_ctrl_transactor->BVALID(s_axi_ctrl_BVALID);
  mp_s_axi_ctrl_transactor->BREADY(s_axi_ctrl_BREADY);
  mp_s_axi_ctrl_transactor->RVALID(s_axi_ctrl_RVALID);
  mp_s_axi_ctrl_transactor->RREADY(s_axi_ctrl_RREADY);
  mp_s_axi_ctrl_transactor->WVALID(s_axi_ctrl_WVALID);
  mp_s_axi_ctrl_transactor->WREADY(s_axi_ctrl_WREADY);
  mp_s_axi_ctrl_transactor->AWADDR(s_axi_ctrl_AWADDR);
  mp_s_axi_ctrl_transactor->AWPROT(s_axi_ctrl_AWPROT);
  mp_s_axi_ctrl_transactor->AWREGION(s_axi_ctrl_AWREGION);
  mp_s_axi_ctrl_transactor->AWQOS(s_axi_ctrl_AWQOS);
  mp_s_axi_ctrl_transactor->WDATA(s_axi_ctrl_WDATA);
  mp_s_axi_ctrl_transactor->WSTRB(s_axi_ctrl_WSTRB);
  mp_s_axi_ctrl_transactor->BRESP(s_axi_ctrl_BRESP);
  mp_s_axi_ctrl_transactor->ARADDR(s_axi_ctrl_ARADDR);
  mp_s_axi_ctrl_transactor->ARPROT(s_axi_ctrl_ARPROT);
  mp_s_axi_ctrl_transactor->ARREGION(s_axi_ctrl_ARREGION);
  mp_s_axi_ctrl_transactor->ARQOS(s_axi_ctrl_ARQOS);
  mp_s_axi_ctrl_transactor->RDATA(s_axi_ctrl_RDATA);
  mp_s_axi_ctrl_transactor->RRESP(s_axi_ctrl_RRESP);
  mp_s_axi_ctrl_transactor->CLK(aclk);
  m_s_axi_ctrl_transactor_rst_signal.write(1);
  mp_s_axi_ctrl_transactor->RST(m_s_axi_ctrl_transactor_rst_signal);
  // configure rp_axi_ctrl_transactor
    xsc::common_cpp::properties rp_axi_ctrl_transactor_param_props;
    rp_axi_ctrl_transactor_param_props.addLong("DATA_WIDTH", "32");
    rp_axi_ctrl_transactor_param_props.addLong("FREQ_HZ", "100000000");
    rp_axi_ctrl_transactor_param_props.addLong("ID_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ADDR_WIDTH", "16");
    rp_axi_ctrl_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("BUSER_WIDTH", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_LOCK", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_PROT", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_CACHE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_QOS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_REGION", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_WSTRB", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_BRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RRESP", "1");
    rp_axi_ctrl_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    rp_axi_ctrl_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    rp_axi_ctrl_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_SIZE", "0");
    rp_axi_ctrl_transactor_param_props.addLong("HAS_RESET", "0");
    rp_axi_ctrl_transactor_param_props.addFloat("PHASE", "0.0");
    rp_axi_ctrl_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    rp_axi_ctrl_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    rp_axi_ctrl_transactor_param_props.addString("CLK_DOMAIN", "");
    rp_axi_ctrl_transactor_param_props.addString("MISC.CLK_REQUIRED", "FALSE");

    mp_rp_axi_ctrl_transactor = new xtlm::xaximm_xtlm2pin_t<32,16,1,1,1,1,1,1>("rp_axi_ctrl_transactor", rp_axi_ctrl_transactor_param_props);
  mp_rp_axi_ctrl_transactor->ARVALID(rp_axi_ctrl_ARVALID);
  mp_rp_axi_ctrl_transactor->ARREADY(rp_axi_ctrl_ARREADY);
  mp_rp_axi_ctrl_transactor->AWVALID(rp_axi_ctrl_AWVALID);
  mp_rp_axi_ctrl_transactor->AWREADY(rp_axi_ctrl_AWREADY);
  mp_rp_axi_ctrl_transactor->BVALID(rp_axi_ctrl_BVALID);
  mp_rp_axi_ctrl_transactor->BREADY(rp_axi_ctrl_BREADY);
  mp_rp_axi_ctrl_transactor->RVALID(rp_axi_ctrl_RVALID);
  mp_rp_axi_ctrl_transactor->RREADY(rp_axi_ctrl_RREADY);
  mp_rp_axi_ctrl_transactor->WVALID(rp_axi_ctrl_WVALID);
  mp_rp_axi_ctrl_transactor->WREADY(rp_axi_ctrl_WREADY);
  mp_rp_axi_ctrl_transactor->AWADDR(rp_axi_ctrl_AWADDR);
  mp_rp_axi_ctrl_transactor->AWPROT(rp_axi_ctrl_AWPROT);
  mp_rp_axi_ctrl_transactor->AWREGION(rp_axi_ctrl_AWREGION);
  mp_rp_axi_ctrl_transactor->AWQOS(rp_axi_ctrl_AWQOS);
  mp_rp_axi_ctrl_transactor->WDATA(rp_axi_ctrl_WDATA);
  mp_rp_axi_ctrl_transactor->WSTRB(rp_axi_ctrl_WSTRB);
  mp_rp_axi_ctrl_transactor->BRESP(rp_axi_ctrl_BRESP);
  mp_rp_axi_ctrl_transactor->ARADDR(rp_axi_ctrl_ARADDR);
  mp_rp_axi_ctrl_transactor->ARPROT(rp_axi_ctrl_ARPROT);
  mp_rp_axi_ctrl_transactor->ARREGION(rp_axi_ctrl_ARREGION);
  mp_rp_axi_ctrl_transactor->ARQOS(rp_axi_ctrl_ARQOS);
  mp_rp_axi_ctrl_transactor->RDATA(rp_axi_ctrl_RDATA);
  mp_rp_axi_ctrl_transactor->RRESP(rp_axi_ctrl_RRESP);
  mp_rp_axi_ctrl_transactor->CLK(aclk);
  m_rp_axi_ctrl_transactor_rst_signal.write(1);
  mp_rp_axi_ctrl_transactor->RST(m_rp_axi_ctrl_transactor_rst_signal);
  // configure s_axi_reg_transactor
    xsc::common_cpp::properties s_axi_reg_transactor_param_props;
    s_axi_reg_transactor_param_props.addLong("DATA_WIDTH", "32");
    s_axi_reg_transactor_param_props.addLong("FREQ_HZ", "100000000");
    s_axi_reg_transactor_param_props.addLong("ID_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ADDR_WIDTH", "1");
    s_axi_reg_transactor_param_props.addLong("AWUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("ARUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("RUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("BUSER_WIDTH", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_LOCK", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_PROT", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_CACHE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_QOS", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_REGION", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_WSTRB", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_BRESP", "1");
    s_axi_reg_transactor_param_props.addLong("HAS_RRESP", "1");
    s_axi_reg_transactor_param_props.addLong("SUPPORTS_NARROW_BURST", "0");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_OUTSTANDING", "1");
    s_axi_reg_transactor_param_props.addLong("MAX_BURST_LENGTH", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_READ_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("NUM_WRITE_THREADS", "1");
    s_axi_reg_transactor_param_props.addLong("RUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("WUSER_BITS_PER_BYTE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_SIZE", "0");
    s_axi_reg_transactor_param_props.addLong("HAS_RESET", "0");
    s_axi_reg_transactor_param_props.addFloat("PHASE", "0.0");
    s_axi_reg_transactor_param_props.addString("PROTOCOL", "AXI4LITE");
    s_axi_reg_transactor_param_props.addString("READ_WRITE_MODE", "READ_WRITE");
    s_axi_reg_transactor_param_props.addString("CLK_DOMAIN", "design_1_zynq_ultra_ps_e_0_0_pl_clk0");

    mp_s_axi_reg_transactor = new xtlm::xaximm_pin2xtlm_t<32,1,1,1,1,1,1,1>("s_axi_reg_transactor", s_axi_reg_transactor_param_props);
  mp_s_axi_reg_transactor->AWADDR(s_axi_reg_awaddr);
  mp_s_axi_reg_transactor->AWVALID(s_axi_reg_awvalid);
  mp_s_axi_reg_transactor->AWREADY(s_axi_reg_awready);
  mp_s_axi_reg_transactor->WDATA(s_axi_reg_wdata);
  mp_s_axi_reg_transactor->WVALID(s_axi_reg_wvalid);
  mp_s_axi_reg_transactor->WREADY(s_axi_reg_wready);
  mp_s_axi_reg_transactor->BRESP(s_axi_reg_bresp);
  mp_s_axi_reg_transactor->BVALID(s_axi_reg_bvalid);
  mp_s_axi_reg_transactor->BREADY(s_axi_reg_bready);
  mp_s_axi_reg_transactor->ARADDR(s_axi_reg_araddr);
  mp_s_axi_reg_transactor->ARVALID(s_axi_reg_arvalid);
  mp_s_axi_reg_transactor->ARREADY(s_axi_reg_arready);
  mp_s_axi_reg_transactor->RDATA(s_axi_reg_rdata);
  mp_s_axi_reg_transactor->RRESP(s_axi_reg_rresp);
  mp_s_axi_reg_transactor->RVALID(s_axi_reg_rvalid);
  mp_s_axi_reg_transactor->RREADY(s_axi_reg_rready);
  mp_s_axi_reg_transactor->CLK(aclk);
  m_s_axi_reg_transactor_rst_signal.write(1);
  mp_s_axi_reg_transactor->RST(m_s_axi_reg_transactor_rst_signal);

  // initialize transactors stubs
  s_stream_a_transactor_target_socket_stub = nullptr;
  rp_stream_a_transactor_initiator_socket_stub = nullptr;
  s_stream_b_transactor_target_socket_stub = nullptr;
  rp_stream_b_transactor_initiator_socket_stub = nullptr;
  s_stream_c_transactor_initiator_socket_stub = nullptr;
  rp_stream_c_transactor_target_socket_stub = nullptr;
  s_axi_ctrl_transactor_target_wr_socket_stub = nullptr;
  s_axi_ctrl_transactor_target_rd_socket_stub = nullptr;
  rp_axi_ctrl_transactor_initiator_wr_socket_stub = nullptr;
  rp_axi_ctrl_transactor_initiator_rd_socket_stub = nullptr;
  s_axi_reg_transactor_target_wr_socket_stub = nullptr;
  s_axi_reg_transactor_target_rd_socket_stub = nullptr;

}

void design_1_dfx_decoupler_0_0::before_end_of_elaboration()
{
  // configure 's_stream_a' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_a_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_a_transactor->socket));
  
  }
  else
  {
    s_stream_a_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    s_stream_a_transactor_target_socket_stub->bind(*(mp_s_stream_a_transactor->socket));
    mp_s_stream_a_transactor->disable_transactor();
  }

  // configure 'rp_stream_a' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_a_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_a_transactor->socket));
  
  }
  else
  {
    rp_stream_a_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    rp_stream_a_transactor_initiator_socket_stub->bind(*(mp_rp_stream_a_transactor->socket));
    mp_rp_stream_a_transactor->disable_transactor();
  }

  // configure 's_stream_b' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_b_TLM_MODE") != 1)
  {
    mp_impl->S01_AXIS_TARGET_SOCKET->bind(*(mp_s_stream_b_transactor->socket));
  
  }
  else
  {
    s_stream_b_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    s_stream_b_transactor_target_socket_stub->bind(*(mp_s_stream_b_transactor->socket));
    mp_s_stream_b_transactor->disable_transactor();
  }

  // configure 'rp_stream_b' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_b_TLM_MODE") != 1)
  {
    mp_impl->M01_AXIS_INITIATOR_SOCKET->bind(*(mp_rp_stream_b_transactor->socket));
  
  }
  else
  {
    rp_stream_b_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    rp_stream_b_transactor_initiator_socket_stub->bind(*(mp_rp_stream_b_transactor->socket));
    mp_rp_stream_b_transactor->disable_transactor();
  }

  // configure 's_stream_c' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_stream_c_TLM_MODE") != 1)
  {
    mp_impl->M02_AXIS_INITIATOR_SOCKET->bind(*(mp_s_stream_c_transactor->socket));
  
  }
  else
  {
    s_stream_c_transactor_initiator_socket_stub = new xtlm::xtlm_axis_initiator_stub("socket",0);
    s_stream_c_transactor_initiator_socket_stub->bind(*(mp_s_stream_c_transactor->socket));
    mp_s_stream_c_transactor->disable_transactor();
  }

  // configure 'rp_stream_c' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_stream_c_TLM_MODE") != 1)
  {
    mp_impl->S02_AXIS_TARGET_SOCKET->bind(*(mp_rp_stream_c_transactor->socket));
  
  }
  else
  {
    rp_stream_c_transactor_target_socket_stub = new xtlm::xtlm_axis_target_stub("socket",0);
    rp_stream_c_transactor_target_socket_stub->bind(*(mp_rp_stream_c_transactor->socket));
    mp_rp_stream_c_transactor->disable_transactor();
  }

  // configure 's_axi_ctrl' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_ctrl_TLM_MODE") != 1)
  {
    mp_impl->S00_AXIMM_TARGET_wr_SOCKET->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    mp_impl->S00_AXIMM_TARGET_rd_SOCKET->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
  
  }
  else
  {
    s_axi_ctrl_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_axi_ctrl_transactor_target_wr_socket_stub->bind(*(mp_s_axi_ctrl_transactor->wr_socket));
    s_axi_ctrl_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_axi_ctrl_transactor_target_rd_socket_stub->bind(*(mp_s_axi_ctrl_transactor->rd_socket));
    mp_s_axi_ctrl_transactor->disable_transactor();
  }

  // configure 'rp_axi_ctrl' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "rp_axi_ctrl_TLM_MODE") != 1)
  {
    mp_impl->M00_AXIMM_INITIATOR_wr_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    mp_impl->M00_AXIMM_INITIATOR_rd_SOCKET->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
  
  }
  else
  {
    rp_axi_ctrl_transactor_initiator_wr_socket_stub = new xtlm::xtlm_aximm_initiator_stub("wr_socket",0);
    rp_axi_ctrl_transactor_initiator_wr_socket_stub->bind(*(mp_rp_axi_ctrl_transactor->wr_socket));
    rp_axi_ctrl_transactor_initiator_rd_socket_stub = new xtlm::xtlm_aximm_initiator_stub("rd_socket",0);
    rp_axi_ctrl_transactor_initiator_rd_socket_stub->bind(*(mp_rp_axi_ctrl_transactor->rd_socket));
    mp_rp_axi_ctrl_transactor->disable_transactor();
  }

  // configure 's_axi_reg' transactor
  if (xsc::utils::xsc_sim_manager::getInstanceParameterInt("design_1_dfx_decoupler_0_0", "s_axi_reg_TLM_MODE") != 1)
  {
    mp_impl->axilite_wr_socket->bind(*(mp_s_axi_reg_transactor->wr_socket));
    mp_impl->axilite_rd_socket->bind(*(mp_s_axi_reg_transactor->rd_socket));
  
  }
  else
  {
    s_axi_reg_transactor_target_wr_socket_stub = new xtlm::xtlm_aximm_target_stub("wr_socket",0);
    s_axi_reg_transactor_target_wr_socket_stub->bind(*(mp_s_axi_reg_transactor->wr_socket));
    s_axi_reg_transactor_target_rd_socket_stub = new xtlm::xtlm_aximm_target_stub("rd_socket",0);
    s_axi_reg_transactor_target_rd_socket_stub->bind(*(mp_s_axi_reg_transactor->rd_socket));
    mp_s_axi_reg_transactor->disable_transactor();
  }

}

#endif // MTI_SYSTEMC




design_1_dfx_decoupler_0_0::~design_1_dfx_decoupler_0_0()
{
  delete mp_s_stream_a_transactor;

  delete mp_rp_stream_a_transactor;

  delete mp_s_stream_b_transactor;

  delete mp_rp_stream_b_transactor;

  delete mp_s_stream_c_transactor;

  delete mp_rp_stream_c_transactor;

  delete mp_s_axi_ctrl_transactor;

  delete mp_rp_axi_ctrl_transactor;

  delete mp_s_axi_reg_transactor;

}

#ifdef MTI_SYSTEMC
SC_MODULE_EXPORT(design_1_dfx_decoupler_0_0);
#endif

#ifdef XM_SYSTEMC
XMSC_MODULE_EXPORT(design_1_dfx_decoupler_0_0);
#endif

#ifdef RIVIERA
SC_MODULE_EXPORT(design_1_dfx_decoupler_0_0);
#endif

